
def prob_134(cheesecake, caramel_cake):
    """
    Args:
        cheesecake: an integer, the number of calories in a slice of cheesecake
        caramel_cake: an integer, the number of calories in a slice of caramel cake

    Returns:
        total_amount_of_sugar: a float, the total amount of sugar consumed
    """
    obj = 1e9
    # To be implemented
    return obj
