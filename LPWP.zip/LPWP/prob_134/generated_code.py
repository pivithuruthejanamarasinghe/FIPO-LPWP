# Import necessary libraries
from gurobipy import Model, GRB

def prob_134(cheesecake, caramel_cake):
    """
    Solves the optimization problem using Gurobi to maximize the total amount of sugar consumed.
    
    Args:
        cheesecake: an integer, the number of calories in a slice of cheesecake
        caramel_cake: an integer, the number of calories in a slice of caramel cake
    
    Returns:
        total_amount_of_sugar: a float, the total amount of sugar consumed
    """
    # Create a new model
    m = Model("cake_optimization")
    
    # Add variables
    x = m.addVar(name="x")  # Number of slices of cheesecake
    y = m.addVar(name="y")  # Number of slices of caramel cake
    
    # Set objective function (maximize total sugar)
    m.setObjective(x * 40 + y * 50, GRB.MAXIMIZE)
    
    # Add constraints
    m.addConstr(x >= 3 * y, "Cheesecake constraint")  # At least 3 times as many slices of cheesecake as caramel cake
    m.addConstr(y >= 3, "Caramel cake constraint")  # At least 3 slices of caramel cake
    m.addConstr(x * cheesecake + y * caramel_cake <= 10000, "Calories constraint")  # Total calories cannot exceed 10000
    
    # Solve the model
    m.optimize()
    
    # Get the optimal solution
    total_amount_of_sugar = x.X * 40 + y.X * 50
    
    return total_amount_of_sugar