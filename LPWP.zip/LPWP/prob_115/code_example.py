
def prob_115(fertilizer, seeds):
    """
    Args:
        fertilizer: a float, the number of minutes taken by fertilizer to be effective
        seeds: a float, the number of minutes taken by seeds to be effective
    Returns:
        obj: a float, the total time it takes for the lawn to be ready
    """
    obj = 1e9
    # To be implemented
    return obj
