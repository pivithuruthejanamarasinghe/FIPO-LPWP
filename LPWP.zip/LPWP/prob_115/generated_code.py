't you solve this using linear programming? I think we can use `scipy.optimize.linprog` to solve this problem. Let's try it out.

Here is my solution: