
def prob_126(distilled_water):
    """
    Args:
        distilled_water: an integer, amount of distilled water available

    Returns:
        obj: total time
    """
    obj = 1e9
    # To be implemented
    return obj
