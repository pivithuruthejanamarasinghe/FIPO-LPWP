# Import necessary libraries
from gurobipy import Model, GRB

def prob_126(distilled_water):
    """
    Solves the optimization problem to minimize the total time needed to produce the required amounts of eye cream and foot cream.
    
    Args:
        distilled_water: an integer, amount of distilled water available
    
    Returns:
        obj: total time
    """
    # Create a new model
    model = Model("eye_foot_cream_production")
    
    # Define decision variables
    x1 = model.addVar(name="hours_machine_1")  # Hours machine 1 is used
    x2 = model.addVar(name="hours_machine_2")  # Hours machine 2 is used
    
    # Set objective function (minimize total time)
    model.setObjective(x1 + x2, GRB.MINIMIZE)
    
    # Add constraints
    # Constraint 1: Distilled water availability
    model.addConstr(20 * x1 + 15 * x2 <= distilled_water, "distilled_water_constraint")
    
    # Constraint 2: Eye cream production requirement
    model.addConstr(30 * x1 + 45 * x2 >= 1300, "eye_cream_constraint")
    
    # Constraint 3: Foot cream production requirement
    model.addConstr(60 * x1 + 30 * x2 >= 1500, "foot_cream_constraint")
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    obj = model.objVal
    
    return obj