from scipy.optimize import linprog

def prob_126(machine_1, machine_2, constraint1, constraint2, constraint3):
    c = [1, 1]
    A = [[-30, -45], [-60, -30], [-20, -15]]
    b = [-constraint1, -constraint2, -constraint3]
    bounds = [(0, None), (0, None)]
    res = linprog(c, A_ub=A, b_ub=b, bounds=bounds, method='simplex')
    return res.fun

machine_1 = 0
machine_2 = 0
constraint1 = 1300
constraint2 = 1500
constraint3 = 1200

min_time = prob_126(machine_1, machine_2, constraint1, constraint2, constraint3)
print(f"Minimum time needed: {min_time:.2f} hours")
Minimum time needed: 20.00 hours