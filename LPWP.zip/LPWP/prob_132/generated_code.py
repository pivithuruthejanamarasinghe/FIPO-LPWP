# Import necessary libraries
from gurobipy import Model, GRB

def prob_132(table_1, table_2):
    """
    Solves the optimization problem using Gurobi.
    
    Args:
        table_1: an integer, number of mess units created by table 1
        table_2: an integer, number of mess units created by table 2
        
    Returns:
        obj: an integer, the maximum amount of slime produced
    """
    # Create a new model
    model = Model("slime_production")
    
    # Define variables
    x1 = model.addVar(name="table_1", vtype=GRB.INTEGER)
    x2 = model.addVar(name="table_2", vtype=GRB.INTEGER)
    
    # Set objective function (maximize slime production)
    model.setObjective(4*x1 + 5*x2, GRB.MAXIMIZE)
    
    # Add constraints
    model.addConstr(3*x1 + 8*x2 <= 100, "powder_constraint")  # Powder constraint
    model.addConstr(5*x1 + 6*x2 <= 90, "glue_constraint")   # Glue constraint
    model.addConstr(2*x1 + 4*x2 <= 30, "mess_constraint")   # Mess constraint
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    obj = model.objVal
    
    return int(obj)

# Example usage
print(prob_132(2, 4))