
def prob_132(table_1, table_2):
    """
    Args:
        table_1: an integer, number of mess units created by table 1
        table_2: an integer, number of mess units created by table 2
    Returns:
        obj: an integer,
    """
    obj = 1e9
    # To be implemented
    return obj
