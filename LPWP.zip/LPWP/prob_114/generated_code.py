# Import necessary libraries
from gurobipy import Model, GRB

def prob_114(apple_flavored_baby, carrot_flavored_baby):
    """
    Solves the baby food optimization problem using Gurobi.
    
    Args:
        apple_flavored_baby: an integer, number of fat units in a serving of apple flavored baby food
        carrot_flavored_baby: an integer, number of fat units in a serving of carrot flavored baby food

    Returns:
        objective_value: an integer, the maximum fat intake
    """
    # Create a new model
    model = Model("baby_food_optimization")
    
    # Define variables
    apple_serving = model.addVar(name="apple_serving", vtype=GRB.INTEGER)
    carrot_serving = model.addVar(name="carrot_serving", vtype=GRB.INTEGER)
    
    # Set objective function (maximize fat intake)
    model.setObjective(apple_flavored_baby * apple_serving + carrot_flavored_baby * carrot_serving, GRB.MAXIMIZE)
    
    # Add constraints
    model.addConstr(carrot_serving >= 2, "minimum_carrot_serving")
    model.addConstr(apple_serving == 3 * carrot_serving, "three_times_apple_to_carrot")
    model.addConstr(apple_flavored_baby * apple_serving + carrot_flavored_baby * carrot_serving <= 100, "folate_limit")
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    objective_value = model.objVal
    
    return int(objective_value)

# Example usage
print(prob_114(2, 4))  # Output will depend on the actual values provided