
def prob_114(apple_flavored_baby, carrot_flavored_baby):
    """
    Args:
        apple_flavored_baby: an integer, number of fat units in a serving of apple flavored baby food
        carrot_flavored_baby: an integer, number of fat units in a serving of carrot flavored baby food

    Returns:
        objective_value: an integer, the maximum fat intake
    """
    objective_value = 1e9
    # To be implemented
    return objective_value
