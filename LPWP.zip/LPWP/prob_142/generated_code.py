# Importing necessary libraries
from gurobipy import Model, GRB

# Scenario 1
def optimize_profit():
    # Create a new model
    m = Model("profit_maximization")
    
    # Decision Variables
    x = m.addVar(name="Product_A", vtype=GRB.INTEGER)
    y = m.addVar(name="Product_B", vtype=GRB.INTEGER)
    
    # Objective Function
    m.setObjective(5*x + 4*y, GRB.MAXIMIZE)
    
    # Constraints
    m.addConstr(2*x + 1*y <= 20, "Resource_X_limit")  # Resource X constraint
    m.addConstr(1*x + 2*y <= 30, "Resource_Y_limit")  # Resource Y constraint
    
    # Solve the model
    m.optimize()
    
    # Print results
    print(f"Optimal number of Product A: {x.x}")
    print(f"Optimal number of Product B: {y.x}")
    print(f"Maximum Profit: ${m.objVal}")

# Scenario 2
def optimize_project_profit():
    # Create a new model
    m = Model("project_profit_maximization")
    
    # Decision Variables
    p1 = m.addVar(name="Project_1", vtype=GRB.BINARY)
    p2 = m.addVar(name="Project_2", vtype=GRB.BINARY)
    p3 = m.addVar(name="Project_3", vtype=GRB.BINARY)
    
    # Objective Function
    m.setObjective(100*p1 + 150*p2 + 200*p3, GRB.MAXIMIZE)
    
    # Constraints
    m.addConstr(p1 + p2 + p3 <= 6, "Total_Projects_limit")  # Only one project per day
    
    # Solve the model
    m.optimize()
    
    # Print results
    print(f"Projects to be worked on: {'Project 1' if p1.x == 1 else ''}, {'Project 2' if p2.x == 1 else ''}, {'Project 3' if p3.x == 1 else ''}")
    print(f"Total Maximum Profit: ${m.objVal}")

# Scenario 3
def optimize_farm_profit():
    # Create a new model
    m = Model("farm_profit_maximization")
    
    # Decision Variables
    w = m.addVar(name="Wheat", vtype=GRB.INTEGER)
    c = m.addVar(name="Corn", vtype=GRB.INTEGER)
    
    # Objective Function
    m.setObjective(100*w + 150*c, GRB.MAXIMIZE)
    
    # Constraints
    m.addConstr(2*w + 1*c <= 10, "Field_Area_limit")  # Field Area constraint
    m.addConstr(50*w + 75*c <= 500, "Budget_limit")  # Budget constraint
    
    # Solve the model
    m.optimize()
    
    # Print results
    print(f"Optimal number of Wheat units: {w.x}")
    print(f"Optimal number of Corn units: {c.x}")
    print(f"Maximum Profit: ${m.objVal}")

# Running the functions
optimize_profit()
optimize_project_profit()
optimize_farm_profit()