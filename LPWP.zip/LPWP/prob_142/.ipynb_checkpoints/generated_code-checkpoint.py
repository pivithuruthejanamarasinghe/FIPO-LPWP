from pulp import LpProblem, LpMaximize, LpVariable, lpSum, LpStatus

def prob_142(experiment_1, experiment_2):
    """
    Calculate the total amount of green gas produced given the number of experiments of type 1 and type 2.

    Args:
        experiment_1: an integer, number of experiments of type 1
        experiment_2: an integer, number of experiments of type 2

    Returns:
        obj: an integer, the objective value (total amount of green gas produced)
    """
    # Calculate the amount of green gas produced
    green_gas_1 = 5 * experiment_1
    green_gas_2 = 6 * experiment_2
    total_green_gas = green_gas_1 + green_gas_2

    return total_green_gas

def main():
    # Define the problem
    prob = LpProblem("Maximize Green Gas Production", LpMaximize)

    # Declare decision variables
    experiment_1 = LpVariable("experiment_1", lowBound=0, cat='Integer')
    experiment_2 = LpVariable("experiment_2", lowBound=0, cat='Integer')

    # Formulate the objective function
    obj = prob_142(experiment_1, experiment_2)
    prob += obj

    # Add constraints
    prob += (3 * experiment_1 + 5 * experiment_2 <= 80) # Constraint on red liquid
    prob += (4 * experiment_1 + 3 * experiment_2 <= 70) # Constraint on blue liquid
    prob += (experiment_1 >= 0) # Non-negativity constraint
    prob += (experiment_2 >= 0) # Non-negativity constraint

    # Solve the problem
    prob.solve()

    # Retrieve and return results
    if LpStatus[prob.status] == 'Optimal':
        print(f"Optimal number of experiments 1: {experiment_1.varValue}")
        print(f"Optimal number of experiments 2: {experiment_2.varValue}")
        print(f"Total amount of green gas produced: {value(prob.objective)}")
    else:
        print("No optimal solution found.")

if __name__ == '__main__':
    main()