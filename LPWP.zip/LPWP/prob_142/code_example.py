
def prob_142(experiment_1, experiment_2):
    """

    Args:
        experiment_1: an integer, number of smelly gas units developed by experiment type 1
        experiment_2: an integer, number of smelly gas units developed by experiment type 2

    Returns:
        obj: an integer, the objective value (total amount of green gas produced)
    """
    # To be implemented
    obj = 1e9
    return obj
