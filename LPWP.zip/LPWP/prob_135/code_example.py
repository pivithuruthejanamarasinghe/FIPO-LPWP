
def prob_135(sulfate, ginger):
    """
    Args:
        sulfate: a float, the number of minutes to effective one unit of sulfate
        ginger: a float, the number of minutes to effective one unit of ginger

    Returns:
        obj: the total amount of time it takes for the mixture to be effective.
    """
    obj = 0
    # To be implemented
    return obj
