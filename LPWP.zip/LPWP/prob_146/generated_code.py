from gurobipy import Model, GRB

def prob_146(blueberries, strawberries):
    """
    Args:
        blueberries: an integer, the number of anti-oxides in a pack of blueberries
        strawberries: an integer, the number of anti-oxides in a pack of strawberries
    Returns:
        sugar_intake: an integer, the minimum sugar intake
    """
    # Create a new model
    m = Model("diet_problem")

    # Define variables
    x = m.addVar(name="blueberries")
    y = m.addVar(name="strawberries")

    # Set objective function (minimize sugar intake)
    m.setObjective(5 * x + 7 * y, GRB.MINIMIZE)

    # Add constraints
    m.addConstr(3 * x + y >= 90, "anti-oxidants_constraint")
    m.addConstr(5 * x + 7 * y >= 100, "minerals_constraint")
    m.addConstr(y >= 3 * x, "strawberry_to_blueberry_ratio_constraint")

    # Solve the model
    m.optimize()

    # Get the optimal solution
    sugar_intake = m.objVal

    return int(sugar_intake)