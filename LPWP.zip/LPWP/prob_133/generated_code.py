# Import necessary library
from gurobipy import Model, GRB

def prob_133(daytime_pills, nighttime_pills):
    """
    Args:
        daytime_pills: an integer, number of painkiller medicine units in a daytime pill
        nighttime_pills: an integer, number of painkiller medicine units in a nighttime pill

    Returns:
        obj: an integer, objective value (amount of sleep medicine)
    """
    # Create a new model
    m = Model("painkiller_optimization")

    # Define variables
    x = m.addVar(name="daytime_pills")
    y = m.addVar(name="nighttime_pills")

    # Set objective function
    m.setObjective(2*x + 5*y, GRB.MINIMIZE)

    # Add constraints
    m.addConstr(x + y <= 800)  # Total units constraint
    m.addConstr(x >= 0.4 * (x + y))  # At least 40% daytime pills
    m.addConstr(y >= 200)  # At least 200 nighttime pills

    # Solve the model
    m.optimize()

    # Get the objective value
    obj = m.objVal

    return int(obj)