
def prob_102(beaker_1, beaker_2):
    """
    Args:
        beaker_1: an integer, number of waste units created by beaker 1
        beaker_2: an integer, number of waste units created by beaker 2

    Returns:
        amount_of_slime: an integer, maximum amount of slime that can be produced
    """
    amount_of_slime = 1e9
    # To be implemented
    return amount_of_slime
