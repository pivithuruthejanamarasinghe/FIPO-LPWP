from pulp import *

def prob_102(beaker_1, beaker_2, constraint1, constraint2, constraint3, constraint4, constraint5, constraint6):
    # Define the problem
    prob = LpProblem("Maximize Slime Production", LpMaximize)

    # Define the decision variables
    beaker_vars = LpVariable("beaker_1", lowBound=0, cat='Integer')
    beaker_vars_2 = LpVariable("beaker_2", lowBound=0, cat='Integer')

    # Define the objective function
    prob += 5*beaker_vars + 3*beaker_vars_2

    # Define the constraints
    prob += 4*beaker_vars + 6*beaker_vars_2 <= constraint1
    prob += 6*beaker_vars + 3*beaker_vars_2 <= constraint2
    prob += 4*beaker_vars + 2*beaker_vars_2 <= constraint3

    # Solve the problem
    prob.solve()

    # Get the optimal solution
    amount_of_slime = value(prob.objective)

    return amount_of_slime

# Test the function
print(prob_102(150, 100, 150, 100, 30, 4, 3))