from pulp import LpProblem, LpMaximize, LpVariable, lpSum, LpStatus

def prob_147(beam_bridges, truss_bridges):
    """
    Args:
        beam_bridges: an integer, representing the number of beam bridges
        truss_bridges: an integer, representing the number of truss bridges
        
    Returns:
        obj: an integer, representing the maximum total mass that can be supported
    """
    # Define the problem
    prob = LpProblem("BridgeBuildingCompetition", LpMaximize)
    
    # Declare decision variables
    x = LpVariable('beam_bridges', lowBound=0, cat='Integer')
    y = LpVariable('truss_bridges', lowBound=0, cat='Integer')
    
    # Formulate the objective function
    prob += lpSum([40 * x + 60 * y])
    
    # Add constraints
    prob += x + y <= 5  # At most 5 truss bridges
    prob += x >= y + 1  # Number of beam bridges must be larger than the number of truss bridges
    prob += 30 * x + 50 * y <= 600  # Popsicle sticks constraint
    prob += 8 * y <= 100  # Glue constraint
    
    # Solve the problem
    prob.solve()
    
    # Check the solution status
    if LpStatus[prob.status] == 'Optimal':
        # Retrieve and return results
        max_mass = lpSum([40 * x + 60 * y])
        return max_mass
    else:
        raise ValueError("The problem does not have an optimal solution.")

def main():
    # Example usage
    try:
        max_mass = prob_147(beam_bridges=0, truss_bridges=0)
        print(f"Maximum total mass that can be supported: {max_mass} grams")
    except ValueError as e:
        print(e)

if __name__ == '__main__':
    main()