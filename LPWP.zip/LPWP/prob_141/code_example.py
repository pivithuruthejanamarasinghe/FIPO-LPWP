
def prob_141(protein, carbs):
    """
    Args:
        protein: an integer, minimum protein needed
        carbs: an integer, minimum carbs needed
    Returns:
        obj: an integer,
    """
    obj = 1e9
    # To be implemented
    return obj
