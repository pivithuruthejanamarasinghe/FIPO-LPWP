from gurobipy import Model, GRB

def prob_141(protein, carbs):
    """
    Solves the body builder's meal optimization problem using Gurobi.
    
    Args:
        protein: an integer, minimum protein needed
        carbs: an integer, minimum carbs needed
    
    Returns:
        obj: an integer, minimum fat intake
    """
    # Create a new model
    model = Model("body_builder_meal")
    
    # Add variables
    turkey_dinner = model.addVar(name="turkey_dinner", vtype=GRB.INTEGER)
    tuna_salad_sandwich = model.addVar(name="tuna_salad_sandwich", vtype=GRB.INTEGER)
    
    # Set objective function (minimize fat intake)
    model.setObjective(12 * turkey_dinner + 8 * tuna_salad_sandwich, GRB.MINIMIZE)
    
    # Add constraints
    model.addConstr(20 * turkey_dinner + 18 * tuna_salad_sandwich >= protein, "protein_constraint")
    model.addConstr(30 * turkey_dinner + 25 * tuna_salad_sandwich >= carbs, "carbs_constraint")
    model.addConstr(turkey_dinner <= 0.4 * (turkey_dinner + tuna_salad_sandwich), "budget_constraint")
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    obj = model.objVal
    
    return int(obj)

# Example usage
print(prob_141(150, 200))