from gurobipy import Model, GRB

def prob_118(vitamin_shots, pills, _30, _40, _50, _10, _7):
    # Create a new model
    m = Model("vitamin_supply")

    # Create variables
    shot_vars = m.addVars(vitamin_shots, name="shots", lb=0, ub=_10)
    pill_vars = m.addVars(pills, name="pills", lb=0, ub=GRB.INFINITY)

    # Add constraints
    m.addConstr(shot_vars.sum() <= _10, "max_shots")
    m.addConstr(_30 * shot_vars.sum() + _50 * pill_vars.sum() <= 1200, "vitamin_c_limit")
    m.addConstr(_40 * shot_vars.sum() + _30 * pill_vars.sum() <= 1500, "vitamin_d_limit")
    m.addConstr(pill_vars >= shot_vars, "more_pills")

    # Set objective
    m.setObjective(shot_vars.prod(_10) + pill_vars.prod(_7), GRB.MAXIMIZE)

    # Optimize the model
    m.optimize()

    # Return the maximum number of people that can be supplied
    return shot_vars.prod(_10) + pill_vars.prod(_7)

# Example usage
max_people = prob_118(10, 20, 30, 40, 50, 10, 7)
print("Maximum number of people that can be supplied:", max_people.getValue())