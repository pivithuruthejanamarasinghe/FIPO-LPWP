
def prob_118(vitamin_shots, pills):
    """
    Args:
        vitamin_shots: an integer, the number of vitamin C units in a vitamin shot
        pills: an integer, the number of vitamin C units in a vitamin pill

    Returns:
        obj: an integer, the maximum number of people that can be supplied
    """
    obj = 1e9
    # To be implemented
    return obj
