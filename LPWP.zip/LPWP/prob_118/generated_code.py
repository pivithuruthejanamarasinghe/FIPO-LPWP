# Import necessary libraries
from gurobipy import Model, GRB

def prob_118(vitamin_shots, pills):
    """
    Args:
        vitamin_shots: an integer, the number of vitamin C units in a vitamin shot
        pills: an integer, the number of vitamin C units in a vitamin pill

    Returns:
        obj: an integer, the maximum number of people that can be supplied
    """
    # Create a new model
    model = Model("vitamin_supply")

    # Define decision variables
    x = model.addVar(name="x")  # Number of vitamin shots
    y = model.addVar(name="y")  # Number of vitamin pills

    # Set objective function (maximize the number of people supplied)
    model.setObjective(10 * x + 7 * y, GRB.MAXIMIZE)

    # Add constraints
    model.addConstr(30 * x + 50 * y <= 1200, "vitamin_C_constraint")
    model.addConstr(40 * x + 30 * y <= 1500, "vitamin_D_constraint")
    model.addConstr(y >= x, "pills_more_than_shots_constraint")
    model.addConstr(x <= 10, "maximum_vitamin_shots_constraint")

    # Solve the model
    model.optimize()

    # Get the optimal solution
    obj = model.objVal

    return int(obj)