't you solve this using linear programming? I think we need to use `scipy.optimize.linprog` for this. Let's try that.

Here is my solution: