
def prob_139(spit_tests, swabs):
    """
    Args:
        spit_tests: an integer, the number of minutes to administer a spit test
        swabs: an integer, the number of minutes to administer a swab
    Returns:
        obj: an integer, the objective value
    """
    obj = 1e9
    # To be implemented
    return obj
