from gurobipy import Model, GRB

def prob_124(gummies, pills):
    """
    Args:
        gummies: an integer, representing the number of magnesium units in a gummy
        pills: an integer, representing the number of magnesium units in a pill

    Returns:
        obj: an integer, representing the maximum zinc intake
    """
    # Create a new model
    m = Model("zinc_intake")

    # Add variables
    x = m.addVar(name="gummies")
    y = m.addVar(name="pills")

    # Set objective
    m.setObjective(4 * x + 5 * y, GRB.MAXIMIZE)

    # Add constraints
    m.addConstr(x >= 3 * y, "gummies_to_pills_ratio")
    m.addConstr(y >= 10, "minimum_pills")
    m.addConstr(3 * x + 2 * y <= 200, "magnesium_limit")

    # Solve the model
    m.optimize()

    # Get the optimal solution
    obj = m.objVal

    return int(obj)