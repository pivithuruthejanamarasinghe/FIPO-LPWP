
def prob_124(gummies, pills):
    """
    Args:
        gummies: an integer, representing the number of magnesium units in a gummy
        pills: an integer, representing the number of magnesium units in a pill

    Returns:
        obj: an integer, representing the maximum zinc intake
    """
    obj = 1e9
    # To be implemented
    return obj
