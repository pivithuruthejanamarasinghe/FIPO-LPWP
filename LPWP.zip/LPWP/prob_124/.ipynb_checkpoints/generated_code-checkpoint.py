from pulp import *

def prob_124(gummies, pills, constraint1, constraint2, constraint3, constraint4, constraint5):
    # Create the problem variable
    prob = LpProblem("Maximize Zinc Intake", LpMaximize)

    # Create the decision variables
    zinc_gummies = LpVariable("Zinc_Gummies", lowBound=0, cat='Integer')
    zinc_pills = LpVariable("Zinc_Pills", lowBound=0, cat='Integer')

    # Define the objective function
    prob += zinc_gummies * 4 + zinc_pills * 5

    # Define the constraints
    prob += zinc_gummies * 3 + zinc_pills * 2 <= constraint4
    prob += zinc_pills >= constraint1
    prob += zinc_gummies >= 3 * zinc_pills
    prob += zinc_gummies + zinc_pills <= constraint2

    # Solve the problem
    prob.solve()

    # Get the optimal solution
    obj = value(prob.objective)

    return obj

# Example usage
gummies = 0
pills = 10
constraint1 = 10
constraint2 = 200
constraint3 = 0
constraint4 = 100
constraint5 = 0

max_zinc = prob_124(gummies, pills, constraint1, constraint2, constraint3, constraint4, constraint5)
print("Maximum Zinc Intake:", max_zinc)