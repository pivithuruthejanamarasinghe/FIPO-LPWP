# Import necessary libraries
from gurobipy import Model, GRB

def prob_108(regular_batch, premium_batch):
    """
    Args:
        regular_batch: an integer, number of medical ingredient units needed for a regular batch
        premium_batch: an integer, number of medical ingredient units needed for a premium batch
    Returns:
        obj: an integer, number of people treated
    """
    # Create a new model
    m = Model("skin_cream_production")

    # Define variables
    x = m.addVar(name="regular_batches")
    y = m.addVar(name="premium_batches")

    # Set objective function (maximize the number of people treated)
    m.setObjective(50 * x + 30 * y, GRB.MAXIMIZE)

    # Add constraints
    m.addConstr(50 * x + 40 * y <= 3000, "medicinal_ingredients_constraint")
    m.addConstr(40 * x + 60 * y <= 3500, "rehydration_product_constraint")
    m.addConstr(x < y, "batch_ratio_constraint")
    m.addConstr(x >= 10, "minimum_regular_batches_constraint")

    # Solve the model
    m.optimize()

    # Get the optimal solution
    obj = int(m.objVal)

    return obj