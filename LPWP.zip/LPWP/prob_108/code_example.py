
def prob_108(regular_batch, premium_batch):
    """
    Args:
        regular_batch: an integer, number of medical ingredient units needed for a regular batch
        premium_batch: an integer, number of medical ingredient units needed for a premium batch
    Returns:
        obj: an integer, number of people treated
    """
    obj = 1e9
    # To be implemented
    return obj
