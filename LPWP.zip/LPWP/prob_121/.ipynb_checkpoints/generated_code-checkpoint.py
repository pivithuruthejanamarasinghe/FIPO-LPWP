from scipy.optimize import minimize

def prob_121(ramen, fries):
    """
    Args:
        ramen: an integer, the number of packs of ramen
        fries: an integer, the number of packs of fries
    Returns:
        obj: an integer, the value of the objective function
    """
    # Objective function: minimize total sodium intake
    obj = (ramen * 100) + (fries * 75)
    
    # Constraints
    # At least 3000 calories
    calories_constraint = (ramen * 400) + (fries * 300) >= 3000
    
    # At least 80 grams of protein
    protein_constraint = (ramen * 20) + (fries * 10) >= 80
    
    # At most 30% of meals can be ramen
    ramen_constraint = ramen / (ramen + fries) <= 0.3
    
    # Combine constraints
    constraints = [calories_constraint, protein_constraint, ramen_constraint]
    
    # Bounds
    bounds = [(0, None), (0, None)]
    
    # Solve optimization problem
    result = minimize(prob_121, [ramen, fries], bounds=bounds, constraints=constraints)
    
    # Return the objective function value
    return result.fun

# Example usage
ramen = 5
fries = 10
obj_value = prob_121(ramen, fries)
print(f"Objective function value: {obj_value}")
print(f"Number of ramen packs: {result.x[0]}")
print(f"Number of fries packs: {result.x[1]}")