def calculate_area(length, width):
    return length * width

# Example usage:
area = calculate_area(5, 3)
print("The area of the rectangle is:", area)
def calculate_area(length: float, width: float) -> float:
    """
    Calculate the area of a rectangle given its length and width.
    
    Parameters:
    - length (float): The length of the rectangle.
    - width (float): The width of the rectangle.
    
    Returns:
    - float: The calculated area of the rectangle.
    """
    return length * width

# Example usage:
area = calculate_area(5.0, 3.0)
print("The area of the rectangle is:", area)