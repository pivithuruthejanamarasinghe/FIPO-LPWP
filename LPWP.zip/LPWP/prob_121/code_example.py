
def prob_121(calories, protein):
    """
    Args:
        calories: an integer, the number of calories needed
        protein: an integer, the number of protein needed
    Returns:
        obj: an integer, the value of the objective function
    """
    obj = 1e9
    # To be implemented
    return obj
