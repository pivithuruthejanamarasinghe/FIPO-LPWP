
def prob_101(alpha, omega):
    """
    Args:
        alpha: an integer representing the number of calories per alpha brand drink
        omega: an integer representing the number of calories per omega brand drink
    Returns:
        obj: an integer representing the objective value (minimized sugar intake)
    """
    obj = 1e9
    # To be implemented
    return obj
