
def prob_101(alpha, omega):
    """
    Args:
        alpha: an integer representing the number of alpha brand drinks
        omega: an integer representing the number of omega brand drinks
    Returns:
        obj: an integer representing the objective value (minimized sugar intake)
    """
    obj = 1e9
    # To be implemented
    return obj
