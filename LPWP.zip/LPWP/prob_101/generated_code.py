# Import necessary libraries
from gurobipy import Model, GRB

def prob_101(alpha, omega):
    """
    Solves the optimization problem using Gurobi.
    
    Args:
        alpha: an integer representing the number of calories per alpha brand drink
        omega: an integer representing the number of calories per omega brand drink
    
    Returns:
        obj: an integer representing the objective value (minimized sugar intake)
    """
    # Create a new model
    model = Model("diet_problem")
    
    # Add variables
    x = model.addVar(name="alpha_drinks", vtype=GRB.CONTINUOUS, lb=0)
    y = model.addVar(name="omega_drinks", vtype=GRB.CONTINUOUS, lb=0)
    
    # Set objective function
    model.setObjective(20 * x + 15 * y, GRB.MINIMIZE)  # Minimize sugar intake
    
    # Add constraints
    model.addConstr(30 * x + 20 * y >= 100, "protein_constraint")  # Protein constraint
    model.addConstr(350 * x + 300 * y >= 2000, "calories_constraint")  # Calories constraint
    model.addConstr(y <= 0.35 * (x + y), "caffeine_constraint")  # Caffeine constraint
    
    # Solve the model
    model.optimize()
    
    # Get the objective value
    obj = model.objVal
    
    return int(obj)

# Example usage
alpha_calories = 350
omega_calories = 300
result = prob_101(alpha_calories, omega_calories)
print(f"Minimum sugar intake: {result} grams")