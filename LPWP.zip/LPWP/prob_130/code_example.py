
def prob_130(pain_killer_1, pain_killer_2):
    """
    Args:
        pain_killer_1: a float, number of units of sleeping medicine delivered by pain killer 1
        pain_killer_2: a float, number of units of sleeping medicine delivered by pain killer 2

    Returns:
        obj: a float, maximum amount of medicine delivered to the back
    """
    obj = 1e9
    # To be implemented
    return obj
