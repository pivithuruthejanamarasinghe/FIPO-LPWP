    # Constraints
    # At most 8 units of sleep medicine should be delivered
    sleep_constraint = pain_killer_1 * 0.3 + pain_killer_2 * 0.6 <= 8
    # At least 4 units of medicine should be delivered to the legs
    leg_constraint = pain_killer_1 * 0.5 + pain_killer_2 * 0.7 >= 4

    # Objective function
    # Maximize the amount of medicine delivered to the back
    back_constraint = pain_killer_1 * 0.8 + pain_killer_2 * 0.4

    # Solve the problem
    from scipy.optimize import linprog
    res = linprog(c=[-back_constraint], A_ub=[leg_constraint, sleep_constraint], b_ub=[4, 8], bounds=(0, None))

    # Output
    print(f"Optimal number of doses of pain killer 1: {res.x[0]}")
    print(f"Optimal number of doses of pain killer 2: {res.x[1]}")
    print(f"Maximum amount of medicine delivered to the back: {-res.fun}")

    return res.fun

# Test the function
print(prob_130(pain_killer_1=0, pain_killer_2=0))

