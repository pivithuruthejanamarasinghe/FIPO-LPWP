# Import necessary libraries
from gurobipy import Model, GRB

def prob_130(pain_killer_1, pain_killer_2):
    """
    Args:
        pain_killer_1: a float, number of units of sleeping medicine delivered by pain killer 1
        pain_killer_2: a float, number of units of sleeping medicine delivered by pain killer 2

    Returns:
        obj: a float, maximum amount of medicine delivered to the back
    """

    # Create a new model
    m = Model("prob_130")

    # Add variables
    x1 = m.addVar(name="x1")  # Number of doses of pain killer 1
    x2 = m.addVar(name="x2")  # Number of doses of pain killer 2

    # Set objective function (maximize medicine delivered to the back)
    m.setObjective(0.8 * x1 + 0.4 * x2, GRB.MAXIMIZE)

    # Add constraints
    m.addConstr(0.5 * x1 + 0.7 * x2 >= 4, "leg_constraint")  # At least 4 units of medicine to the legs
    m.addConstr(0.3 * x1 + 0.6 * x2 <= 8, "sleep_constraint")  # At most 8 units of sleep medicine

    # Solve the model
    m.optimize()

    # Get the optimal value of the objective function
    obj = m.objVal

    return obj