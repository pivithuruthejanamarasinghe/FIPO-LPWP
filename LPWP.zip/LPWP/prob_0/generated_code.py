# Import necessary libraries
from gurobipy import Model, GRB

def prob_0(DogCapability, TruckCapability):
    """
    Solves an optimization problem to maximize the number of fish transported using sled dogs and trucks.
    
    Args:
        DogCapability: an integer, indicates the amount of fish which sled dogs can take per trip
        TruckCapability: an integer, indicates the amount of fish which trucks can take per trip
    
    Returns:
        FishTransported: an integer, denotes the maximum amount of fish that can be transported
    """
    # Create a new model
    model = Model("fish_transportation")
    
    # Add variables
    num_dog_trips = model.addVar(vtype=GRB.INTEGER, name="num_dog_trips")
    num_truck_trips = model.addVar(vtype=GRB.INTEGER, name="num_truck_trips")
    
    # Set objective: Maximize the total number of fish transported
    model.setObjective(num_dog_trips * DogCapability + num_truck_trips * TruckCapability, GRB.MAXIMIZE)
    
    # Add constraints
    model.addConstr(num_dog_trips <= num_truck_trips, "DogTripsLessThanTruckTrips")
    model.addConstr(num_dog_trips * DogCapability + num_truck_trips * TruckCapability <= budget, "BudgetConstraint")
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    FishTransported = model.objVal
    
    return int(FishTransported)

# Example usage
budget = 1000  # Define the budget here
DogCapability = 50  # Amount of fish per trip by sled dogs
TruckCapability = 100  # Amount of fish per trip by trucks
result = prob_0(DogCapability, TruckCapability)
print(f"Maximum fish transported: {result}")