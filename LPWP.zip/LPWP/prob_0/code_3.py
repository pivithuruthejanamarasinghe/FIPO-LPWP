import os
import numpy as np
import json
from gurobipy import Model, GRB, quicksum

model = Model("OptimizationProblem")

# Check if the data.json file exists before attempting to open it
data_file = "data.json"
if not os.path.isfile(data_file):
    raise FileNotFoundError(f"{data_file} not found. Please ensure the file exists in the directory.")

with open(data_file, "r") as f:
    data = json.load(f)

### Define the parameters
MaxFish = data["MaxFish"]  # The maximum number of fish that can be transported
SledDogCapacity = data["SledDogCapacity"]  # The amount of fish that can be transported per trip using local sled dogs
TruckCapacity = data["TruckCapacity"]  # The amount of fish that can be transported per trip using trucks
SledDogCost = data["SledDogCost"]  # The cost per trip for local sled dogs
TruckCost = data["TruckCost"]  # The cost per trip for trucks
Budget = data["Budget"]  # The upper limit of the budget for transportation

### Define the variables
NumSledDogTrips = model.addVar(lb=0, vtype=GRB.INTEGER, name="NumSledDogTrips")
NumTruckTrips = model.addVar(lb=0, vtype=GRB.INTEGER, name="NumTruckTrips")

### Define the constraints
model.addConstr(SledDogCost * NumSledDogTrips + TruckCost * NumTruckTrips <= Budget, "BudgetConstraint")
model.addConstr(NumSledDogTrips <= NumTruckTrips - 1, "TripConstraint")  # Correcting the strict inequality to <=
model.addConstr(SledDogCapacity * NumSledDogTrips + TruckCapacity * NumTruckTrips <= MaxFish, "FishConstraint")

### Define the objective
model.setObjective(SledDogCapacity * NumSledDogTrips + TruckCapacity * NumTruckTrips, GRB.MAXIMIZE)

### Optimize the model
model.optimize()

### Output optimal objective value
if model.status == GRB.OPTIMAL:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
    print("Optimal Objective Value: ", model.objVal)
else:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))