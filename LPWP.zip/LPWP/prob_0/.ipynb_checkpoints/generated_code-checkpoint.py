from pulp import *

def prob_0(DogCapability,TruckCapability,DogCost,TruckCost,MaxBudget):
    """

    Args:
        DogCapability: an integer, indicates the amount of fish which sled dogs can take per trip
        TruckCapability: an integer, indicates the amount of fish which trucks can take per trip
        DogCost: an integer, indicates the cost per trip for a sled dog
        TruckCost: an integer, indicates the cost per trip for a truck
        MaxBudget: an integer, denotes the upper limit of the budget

    Returns:
        FishTransported: an integer, denotes the amount of fish transported after calculation
    """
    # Create the 'prob' variable to contain the problem data
    prob = LpProblem("Fish Transportation Problem", LpMaximize)

    # Create decision variables
    num_dog_trips = LpVariable("num_dog_trips", lowBound=0, cat='Integer')
    num_truck_trips = LpVariable("num_truck_trips", lowBound=0, cat='Integer')

    # Objective function
    prob += num_dog_trips * DogCapability + num_truck_trips * TruckCapability, "Total Fish Transported"

    # Constraints
    prob += num_dog_trips * DogCost <= MaxBudget, "Budget Constraint for Dog Trips"
    prob += num_truck_trips * TruckCost <= MaxBudget, "Budget Constraint for Truck Trips"
    prob += num_dog_trips < num_truck_trips, "Number of Dog Trips Less than Truck Trips"

    # Solve the problem
    prob.solve()

    # Get the optimized values
    num_dog_trips = value(num_dog_trips)
    num_truck_trips = value(num_truck_trips)

    # Calculate the total fish transported
    FishTransported = num_dog_trips * DogCapability + num_truck_trips * TruckCapability

    return FishTransported

# Test the function
DogCapability = 10
TruckCapability = 50
DogCost = 20
TruckCost = 100
MaxBudget = 1000

print(prob_0(DogCapability,TruckCapability,DogCost,TruckCost,MaxBudget))