def prob_0(DogCapability,TruckCapability):
    """

    Args:
        DogCapability: an integer, indicates the amount of fish which sled dogs can take per trip
        TruckCapability: an integer, indicates the amount of fish which trucks can take per trip


    Returns:
        FishTransported: an integer, denotes the amount of fish transported after calculation
    """
    # To be implemented
    FishTransported = 0
    return FishTransported