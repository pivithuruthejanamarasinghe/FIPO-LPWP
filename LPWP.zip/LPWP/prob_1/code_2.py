import os
import numpy as np
from gurobipy import Model, GRB

# Define the parameters directly in the code
MaxColorPrinters = 20  # The maximum number of color printers that can be produced per day
MaxBWPrinters = 30     # The maximum number of black and white printers that can be produced per day
MaxPaperTrayUsage = 35 # The maximum total number of printers (color and black and white) that can be produced using the paper tray machine per day
ProfitColorPrinter = 200  # The profit generated per color printer
ProfitBWPrinter = 70      # The profit generated per black and white printer

model = Model("OptimizationProblem")

### Define the variables
xColorPrinters = model.addVar(vtype=GRB.INTEGER, name="xColorPrinters")
xBWPrinters = model.addVar(vtype=GRB.INTEGER, name="xBWPrinters")

### Define the constraints
model.addConstr(xColorPrinters <= MaxColorPrinters)
model.addConstr(xBWPrinters <= MaxBWPrinters)
model.addConstr(xColorPrinters + xBWPrinters <= MaxPaperTrayUsage)
model.addConstr(xColorPrinters >= 0)
model.addConstr(xBWPrinters >= 0)

### Define the objective
model.setObjective(ProfitColorPrinter * xColorPrinters + ProfitBWPrinter * xBWPrinters, GRB.MAXIMIZE)

### Optimize the model
model.optimize()

### Output optimal objective value
if model.status == GRB.OPTIMAL:
    print("Optimal Objective Value: ", model.objVal)
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
else:
    print("Optimization was not successful. Status code: ", model.status)
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))