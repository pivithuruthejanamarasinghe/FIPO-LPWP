import os
import numpy as np
import json 
from gurobipy import Model, GRB, quicksum

model = Model("OptimizationProblem")

with open("data.json", "r") as f:
    data = json.load(f)

### Define the parameters
MaxColorPrinters = data["MaxColorPrinters"]  # shape: [], definition: The maximum number of color printers that can be produced per day
MaxBWPrinters = data["MaxBWPrinters"]        # shape: [], definition: The maximum number of black and white printers that can be produced per day
MaxPaperTrayUsage = data["MaxPaperTrayUsage"]  # shape: [], definition: The maximum total number of printers (color and black and white) that can be produced using the paper tray machine per day
ProfitColorPrinter = data["ProfitColorPrinter"]  # shape: [], definition: The profit generated per color printer
ProfitBWPrinter = data["ProfitBWPrinter"]          # shape: [], definition: The profit generated per black and white printer

### Define the variables
xColorPrinters = model.addVar(vtype=GRB.INTEGER, name="xColorPrinters")
xBWPrinters = model.addVar(vtype=GRB.INTEGER, name="xBWPrinters")

### Define the constraints
model.addConstr(xColorPrinters <= MaxColorPrinters)
model.addConstr(xBWPrinters <= MaxBWPrinters)
model.addConstr(xColorPrinters + xBWPrinters <= MaxPaperTrayUsage)
model.addConstr(xColorPrinters >= 0)
model.addConstr(xBWPrinters >= 0)

### Define the objective
model.setObjective(200 * xColorPrinters + 70 * xBWPrinters, GRB.MAXIMIZE)

### Optimize the model
model.optimize()

### Output optimal objective value
if model.status == GRB.OPTIMAL:
    print("Optimal Objective Value: ", model.objVal)
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
else:
    print("Optimization was not successful. Status code: ", model.status)
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))