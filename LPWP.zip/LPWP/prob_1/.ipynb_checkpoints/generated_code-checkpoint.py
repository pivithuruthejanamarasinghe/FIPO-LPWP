from pulp import *

def prob_1():
    # Create the 'prob' variable to contain the problem data
    prob = LpProblem("Maximize Profit", LpMaximize)

    # Create decision variables
    color_printers = LpVariable("Color Printers", lowBound=0, upBound=20, cat='Integer')
    bw_printers = LpVariable("Black and White Printers", lowBound=0, upBound=30, cat='Integer')

    # The objective function is added to 'prob' first
    prob += 200 * color_printers + 70 * bw_printers, "Total Profit"

    # The constraints are added to 'prob'
    prob += color_printers + bw_printers <= 35, "Paper Tray Constraint"

    # The problem is solved using PuLP's choice of Solver
    prob.solve()

    # The status of the solution is printed to the screen
    print("Status:", LpStatus[prob.status])

    # Each of the variables is printed with it's resolved optimum value
    for v in prob.variables():
        print(v.name, "=", v.varValue)

    # The optimized objective function value is printed to the console
    print("Total Profit = ", value(prob.objective))

prob_1()