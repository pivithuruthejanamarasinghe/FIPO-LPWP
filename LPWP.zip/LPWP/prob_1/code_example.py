
def prob_1(color_printers, bw_printers):
    """
    Args:
        color_printers: an integer representing the maximum number of color printers can be produced per day
        bw_printers: an integer representing the maximum number of black and white printers can be produced per day
    
    Returns:
        obj: an integer representing the optimal objective value (profit)
    """
    obj = 1e9
    # To be implemented
    return obj
