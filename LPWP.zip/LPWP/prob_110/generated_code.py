# Import necessary libraries
from gurobipy import Model, GRB

def prob_110(syrup_1, syrup_2):
    """
    Args:
        syrup_1: a float, the number of sugar units in a serving of syrup 1
        syrup_2: a float, the number of sugar units in a serving of syrup 2
    Returns:
        obj: a float, the objective value (sugar intake)
    """
    # Create a new model
    model = Model("min_sugar_intake")
    
    # Add variables
    x = model.addVar(name="x")  # Number of servings of syrup 1
    y = model.addVar(name="y")  # Number of servings of syrup 2
    
    # Set objective function
    model.setObjective(x * syrup_1 + y * syrup_2, GRB.MINIMIZE)
    
    # Add constraints
    model.addConstr(0.5 * x + 0.2 * y >= 5, "throat_medicine")
    model.addConstr(0.4 * x + 0.5 * y <= 4, "lung_medicine")
    model.addConstr(x >= 0, "non_negative_x")
    model.addConstr(y >= 0, "non_negative_y")
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    obj = model.objVal
    
    return obj