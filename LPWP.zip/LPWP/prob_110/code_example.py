
def prob_110(syrup_1, syrup_2):
    """
    Args:
        syrup_1: a float, the number of sugar units in a serving of syrup 1
        syrup_2: a float, the number of sugar units in a serving of syrup 2
    Returns:
        obj: a float, the objective value (sugar intake)
    """
    obj = 1e9
    # To be implemented
    return obj
