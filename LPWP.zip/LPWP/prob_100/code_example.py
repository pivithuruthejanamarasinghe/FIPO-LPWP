
def prob_100(Pill_1, Pill_2):
    """
    Args:
        Pill_1: a float, the number of discharge units created by Pill 1
        Pill_2: a float, the number of discharge units created by Pill 2
    Returns:
        obj: a float, the total amount of discharge
    """
    obj = 1e9
    # To be implemented
    return obj
