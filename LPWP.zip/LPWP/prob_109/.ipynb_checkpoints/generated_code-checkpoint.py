from pulp import LpProblem, LpMaximize, LpVariable, lpSum, LpStatus, value

def prob_109(automatic_machine, manual_machine):
    """
    Args:
        automatic_machine: an integer, representing the number of patients using the automatic machine
        manual_machine: an integer, representing the number of patients using the manual machine

    Returns:
        obj: an integer, representing the maximum number of patients whose blood pressure can be taken
    """
    # Create the problem variable to contain the problem data
    prob = LpProblem("Maximize_Patients", LpMaximize)

    # Define the decision variables
    # Time taken by automatic machine per patient (in minutes)
    time_auto = 10
    # Time taken by manual machine per patient (in minutes)
    time_manual = 15

    # Decision variables for the number of patients
    x = LpVariable('x', lowBound=0, cat='Integer')
    y = LpVariable('y', lowBound=0, cat='Integer')

    # Objective function: Maximize the number of patients
    prob += x + y

    # Constraints
    # At least twice as many patients must have their blood pressure taken by the manual machine
    prob += y >= 2 * x

    # At least 20 patients can be processed by the automatic machine
    prob += x >= 20

    # Total time constraint
    prob += time_auto * x + time_manual * y <= 20000

    # Solve the problem
    prob.solve()

    # Check if a solution exists
    if LpStatus[prob.status] == 'Optimal':
        # Retrieve and return the results
        obj = value(prob.objective)
        return obj
    else:
        raise ValueError("No optimal solution found.")

# Example usage
try:
    max_patients = prob_109(automatic_machine=0, manual_machine=0)
    print(f"Maximum number of patients whose blood pressure can be taken: {max_patients}")
except ValueError as e:
    print(e)