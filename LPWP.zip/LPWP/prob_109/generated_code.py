from gurobipy import Model, GRB

def prob_109(automatic_machine, manual_machine):
    """
    Args:
        automatic_machine: an integer, representing the number of minutes taken by an automatic machine
        manual_machine: an integer, representing the number of minutes taken by a manual machine

    Returns:
        obj: an integer, representing the maximum number of patients whose blood pressure can be taken
    """
    # Create a new model
    m = Model("blood_pressure")

    # Add variables
    auto_patients = m.addVar(name="auto_patients", vtype=GRB.INTEGER)
    manu_patients = m.addVar(name="manu_patients", vtype=GRB.INTEGER)

    # Set objective
    m.setObjective(auto_patients + manu_patients, GRB.MAXIMIZE)

    # Add constraints
    m.addConstr(manu_patients >= 2 * auto_patients, "manual_to_auto_ratio")
    m.addConstr(auto_patients >= 20, "minimum_auto_patients")
    m.addConstr(auto_patients * automatic_machine + manu_patients * manual_machine <= 20000, "total_time_constraint")

    # Solve the model
    m.optimize()

    # Get the solution
    obj = int(m.objVal)

    return obj