from pulp import LpProblem, LpMinimize, LpVariable, lpSum

def prob_140(Beam_1, Beam_2):
    """
    Args:
        Beam_1: an integer, the number of minutes of Beam 1 used
        Beam_2: an integer, the number of minutes of Beam 2 used

    Returns:
        obj: an integer, the minimized total radiation received by the pancreas
    """
    # Define the problem
    prob = LpProblem("Radiation_Treatment", LpMinimize)

    # Declare decision variables
    x1 = LpVariable('x1', lowBound=0, cat='Integer')  # Minutes of Beam 1
    x2 = LpVariable('x2', lowBound=0, cat='Integer')  # Minutes of Beam 2

    # Formulate the objective function
    # Minimize the total radiation received by the pancreas
    prob += lpSum([0.3 * x1 + 0.2 * x2, 0.6 * x1 + 0.4 * x2])

    # Add constraints
    # At most 4 units of medicine should be received by the skin
    prob += 0.2 * x1 + 0.1 * x2 <= 4

    # At least 3 units of medicine should be delivered to the tumor
    prob += 0.6 * x1 + 0.4 * x2 >= 3

    # Solve the problem
    prob.solve()

    # Check the solution status
    if LpStatus[prob.status] == 'Optimal':
        # Retrieve and return results
        obj = value(prob.objective)
        return obj
    else:
        raise ValueError("The problem does not have an optimal solution.")

# Example usage:
try:
    optimal_radiation = prob_140(Beam_1=0, Beam_2=0)  # Initial guess
    print(f"Minimized total radiation received by the pancreas: {optimal_radiation}")
except ValueError as e:
    print(e)