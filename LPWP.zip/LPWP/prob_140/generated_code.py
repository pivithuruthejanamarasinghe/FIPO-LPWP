# Import necessary libraries
from gurobipy import Model, GRB

def prob_140(Beam_1, Beam_2):
    """
    Args:
        Beam_1: a float, the number of medicine units delivered by Beam 1 per minute
        Beam_2: a float, the number of medicine units delivered by Beam 2 per minute

    Returns:
        obj: a float, the minimized total radiation received by the pancreas
    """
    # Create a new model
    model = Model("radiation_treatment")

    # Define variables
    x1 = model.addVar(name="Beam_1_minutes")
    x2 = model.addVar(name="Beam_2_minutes")

    # Set objective function
    model.setObjective(0.3 * x1 + 0.2 * x2, GRB.MINIMIZE)

    # Add constraints
    model.addConstr(0.2 * x1 + 0.1 * x2 <= 4, "Skin_constraint")  # At most 4 units of medicine should be received by the skin
    model.addConstr(0.6 * x1 + 0.4 * x2 >= 3, "Tumor_constraint")  # At least 3 units of medicine should be delivered to the tumor

    # Solve the model
    model.optimize()

    # Get the optimal solution
    obj = model.objVal

    return obj