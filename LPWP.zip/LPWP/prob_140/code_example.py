
def prob_140(Beam_1, Beam_2):
    """
    Args:
        Beam_1: a float, the number of medicine units delivered by Beam 1 per minute
        Beam_2: a float, the number of medicine units delivered by Beam 2 per minute

    Returns:
        obj: a float, the minimized total radiation received by the pancreas
    """
    obj = 1e9
    # To be implemented
    return obj
