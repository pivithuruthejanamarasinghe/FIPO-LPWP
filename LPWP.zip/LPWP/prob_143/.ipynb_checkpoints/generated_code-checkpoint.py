from pulp import LpProblem, LpMinimize, LpVariable, lpSum, LpStatus

def prob_143(large_pill, small_pill):
    """
    Args:
        large_pill: an integer representing the number of large pills
        small_pill: an integer representing the number of small pills

    Returns:
        obj: an integer representing the number of filler material needed
    """
    # Define the problem
    prob = LpProblem("MinimizeFillerMaterial", LpMinimize)

    # Declare decision variables
    filler_large = LpVariable('filler_large', lowBound=0, cat='Integer')
    filler_small = LpVariable('filler_small', lowBound=0, cat='Integer')

    # Formulate the objective function
    prob += lpSum([filler_large, filler_small])

    # Add constraints
    prob += large_pill * 2 <= filler_large
    prob += small_pill * 1 <= filler_small
    prob += large_pill >= 100
    prob += small_pill >= 0.6 * (large_pill + small_pill)

    # Solve the problem
    prob.solve()

    # Check the solution status
    if LpStatus[prob.status] == 'Optimal':
        # Retrieve and return results
        obj = prob.objective.value()
        print(f"Optimal number of large pills: {int(large_pill.value())}")
        print(f"Optimal number of small pills: {int(small_pill.value())}")
        print(f"Minimum filler material needed: {obj}")
        return obj
    else:
        print("No optimal solution found.")
        return None

def main():
    """
    This function solves the optimization problem and prints the results.
    """
    # Initial guess for the number of large and small pills
    large_pill = LpVariable('large_pill', lowBound=100, cat='Integer')
    small_pill = LpVariable('small_pill', lowBound=0, cat='Integer')

    # Solve the problem
    prob_143(large_pill, small_pill)

if __name__ == '__main__':
    main()