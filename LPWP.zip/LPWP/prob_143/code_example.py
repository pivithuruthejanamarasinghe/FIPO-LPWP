
def prob_143(large_pill, small_pill):
    """
    Args:
        large_pill: an integer representing the number of medical ingredients units needed for a large pill
        small_pill: an integer representing the number of medical ingredients units needed for a small pill

    Returns:
        obj: an integer representing the number of filler material needed
    """
    obj = 1e9
    # To be implemented
    return obj
