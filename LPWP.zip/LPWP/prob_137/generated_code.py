from gurobipy import Model, GRB

def prob_137(oranges, grapefruit):
    """
    Args:
        oranges: an integer, the number of vitamin C units in an orange
        grapefruit: an integer, the number of vitamin C units in a grapefruit
    Returns:
        obj: an integer, the minimum sugar intake
    """
    # Create a new model
    model = Model("vitamin_c_and_a")

    # Add variables
    x = model.addVar(name="oranges")
    y = model.addVar(name="grapefruits")

    # Set objective function
    model.setObjective(5 * x + 6 * y, GRB.MINIMIZE)

    # Add constraints
    model.addConstr(5 * x + 7 * y >= 80, "min_vitamin_C")
    model.addConstr(3 * x + 5 * y >= 70, "min_vitamin_A")
    model.addConstr(x >= 2 * y, "orange_to_grapefruit_ratio")

    # Solve the model
    model.optimize()

    # Get the optimal solution
    obj = model.objVal

    return int(obj)