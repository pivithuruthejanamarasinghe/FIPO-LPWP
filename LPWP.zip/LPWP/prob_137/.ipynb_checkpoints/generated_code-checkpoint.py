from gurobipy import Model, GRB, quicksum

def prob_137(oranges, grapefruit):
    """
    Args:
        oranges: an integer, the number of oranges to eat
        grapefruit: an integer, the number of grapefruit to eat
    Returns:
        obj: an integer, the minimum sugar intake
    """
    # Create a new model
    m = Model("Optimization Problem")

    # Decision variables
    x = m.addVar(name="oranges", vtype=GRB.INTEGER, lb=0)
    y = m.addVar(name="grapefruit", vtype=GRB.INTEGER, lb=0)

    # Objective function
    sugar = quicksum(5 * x + 6 * y)
    m.setObjective(sugar, GRB.MINIMIZE)

    # Constraints
    m.addConstr(5 * x + 7 * y >= 80, "vitaminC")
    m.addConstr(3 * x + 5 * y >= 70, "vitaminA")
    m.addConstr(x >= 2 * y, "oranges_grapefruit_ratio")

    # Solve the problem
    m.optimize()

    # Check if a feasible solution was found
    if m.status == GRB.OPTIMAL:
        # Retrieve the values of the decision variables
        oranges_val = x.X
        grapefruit_val = y.X
        min_sugar = m.objVal

        # Return the results
        return min_sugar, oranges_val, grapefruit_val
    else:
        raise Exception("No feasible solution found")

# Example usage
try:
    min_sugar, oranges, grapefruit = prob_137(oranges=0, grapefruit=0)
    print(f"Minimum sugar intake: {min_sugar}")
    print(f"Oranges to eat: {oranges}")
    print(f"Grapefruit to eat: {grapefruit}")
except Exception as e:
    print(e)