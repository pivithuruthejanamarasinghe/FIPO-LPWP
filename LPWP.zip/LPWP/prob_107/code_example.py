
def prob_107(fish, chicken):
    """
    Args:
        fish: an integer, number of protein units in a fish meal
        chicken: an integer, number of protein units in a chicken meal
    Returns:
        obj: an integer, minimized fat intake
    """
    obj = 1e9
    # To be implemented
    return obj
