from pulp import LpProblem, LpMinimize, LpVariable, lpSum

def prob_107(fish, chicken):
    """
    Args:
        fish: an integer, number of fish meals
        chicken: an integer, number of chicken meals
    Returns:
        obj: an integer, minimized fat intake
    """
    # Define the problem
    prob = LpProblem("MinimizeFatIntake", LpMinimize)

    # Declare decision variables
    fish_var = LpVariable('fish', lowBound=0, cat='Integer')
    chicken_var = LpVariable('chicken', lowBound=0, cat='Integer')

    # Formulate the objective function
    prob += lpSum([7 * fish_var + 10 * chicken_var])

    # Add constraints
    prob += fish_var + 2 * chicken_var >= 130  # Protein constraint
    prob += 12 * fish_var + 8 * chicken_var >= 120  # Iron constraint
    prob += chicken_var >= 2 * fish_var  # Preference constraint

    # Solve the problem
    prob.solve()

    # Check if a solution exists
    if prob.status == 1:
        # Retrieve and return results
        obj = prob.objective.value()
        return obj
    else:
        raise ValueError("No feasible solution found.")

# Example usage:
try:
    minimized_fat = prob_107(fish=0, chicken=0)
    print(f"Minimized fat intake: {minimized_fat}")
except ValueError as e:
    print(e)