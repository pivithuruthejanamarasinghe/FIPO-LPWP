from scipy.optimize import linprog

def prob_129(throat_swabs, nasal_swabs):
    """
    Args:
        throat_swabs: an integer, the number of throat swabs
        nasal_swabs: an integer, the number of nasal swabs
        
    Returns:
        number_of_patients: an integer, the number of patients
    """
    # Objective function coefficients (we want to maximize the number of patients, hence -1)
    c = [-1, -1]
    
    # Inequality constraints matrix (Ax <= b)
    # 1. The total time spent on swabs must not exceed 20000 minutes
    # 2. At least 30 nasal swabs must be done
    # 3. At least 4 times as many throat swabs as nasal swabs
    A = [[5 * throat_swabs + 3 * nasal_swabs, -1],
         [-3 * nasal_swabs, -1],
         [-4 * nasal_swabs, 0]]
    
    # Inequality constraints vector
    b = [20000, -30, 0]
    
    # Bounds for each variable (throat_swabs and nasal_swabs must be non-negative)
    x0_bounds = (0, None)
    x1_bounds = (0, None)
    
    # Solve the linear programming problem
    res = linprog(c, A_ub=A, b_ub=b, bounds=[x0_bounds, x1_bounds], method='highs')
    
    if res.success:
        number_of_patients = -res.fun  # Convert back to maximization problem
    else:
        number_of_patients = 0  # Infeasible solution
    
    return int(number_of_patients)

# Example usage:
throat_swabs = 0
nasal_swabs = 0
print(prob_129(throat_swabs, nasal_swabs))