# Importing the required library
from gurobipy import Model, GRB

def prob_129(throat_swabs, nasal_swabs):
    """
    Args:
        throat_swabs: an integer, the number of minutes for a throat swab
        nasal_swabs: an integer, the number of minutes for a nasal swab
        
    Returns:
        number_of_patients: an integer, the number of patients
    """
    # Create a new model
    m = Model("swab_optimization")
    
    # Add variables
    x = m.addVar(name="throat_swabs", vtype=GRB.INTEGER)
    y = m.addVar(name="nasal_swabs", vtype=GRB.INTEGER)
    
    # Set objective function (maximize the number of patients)
    m.setObjective(x + y, GRB.MAXIMIZE)
    
    # Add constraints
    m.addConstr(nasal_swabs * y >= 30)  # At least 30 nasal swabs
    m.addConstr(throat_swabs * x >= 4 * nasal_swabs * y)  # At least 4 times as many throat swabs
    m.addConstr(throat_swabs * x + nasal_swabs * y <= 20000)  # Total time constraint
    
    # Solve the model
    m.optimize()
    
    # Get the optimal solution
    number_of_patients = int(m.objVal)
    
    return number_of_patients