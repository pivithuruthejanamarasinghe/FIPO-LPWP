
def prob_123(morphine):
    """
    Args:
        morphine: an integer, representing the number of available morphine
    Returns:
        amount_of_digestive_medicine: an integer, representing the total amount of digestive medicine needed  
    """
    obj = 1e9
    # To be implemented
    return obj
