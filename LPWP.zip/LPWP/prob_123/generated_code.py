# Importing the required library
from gurobipy import Model, GRB

def prob_123(morphine):
    """
    Args:
        morphine: an integer, representing the number of available morphine (in mg)
    Returns:
        amount_of_digestive_medicine: an integer, representing the total amount of digestive medicine needed  
    """
    # Create a new model
    model = Model("pharmacy_pills")

    # Define variables
    painkillers = model.addVar(name="painkillers", vtype=GRB.INTEGER)
    sleeping_pills = model.addVar(name="sleeping_pills", vtype=GRB.INTEGER)

    # Set objective function
    model.setObjective(painkillers * 3 + sleeping_pills * 5, GRB.MINIMIZE)

    # Add constraints
    model.addConstr(painkillers * 10 + sleeping_pills * 6 <= morphine, "morphine_constraint")
    model.addConstr(painkillers >= 50, "minimum_painkillers")
    model.addConstr(sleeping_pills >= 0.7 * (painkillers + sleeping_pills), "at_least_70_sleeping_pills")

    # Solve the model
    model.optimize()

    # Get the solution
    amount_of_digestive_medicine = int(painkillers.X * 3 + sleeping_pills.X * 5)

    return amount_of_digestive_medicine