


# Test the function
long_profit = 12
short_profit = 5
print(prob_14(long_profit, short_profit))
```

't














s
