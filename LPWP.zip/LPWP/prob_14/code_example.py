
def prob_14(long, short_cables):
    """
    Args:
        long: an integer, the profit of a long cable
        short_cables: an integer, the profit of a short cable

    Returns:
        obj: an integer, the objective value
    """
    obj = 1e9
    # To be implemented
    return obj
