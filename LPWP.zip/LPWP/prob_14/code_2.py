import numpy as np
from gurobipy import Model, GRB

# Define the parameters directly in the code
TotalGoldAvailable = 1000  # Total amount of gold available in mg
GoldPerLongCable = 10  # Gold required for one long cable
GoldPerShortCable = 7  # Gold required for one short cable
MinLongCables = 10  # Minimum number of long cables
ProfitPerLongCable = 12  # Profit from one long cable
ProfitPerShortCable = 5  # Profit from one short cable
ShortCableRequirement = 5  # At least 5 times more short cables than long cables

# Create the optimization model
model = Model("OptimizationProblem")

# Define the variables
L = model.addVar(vtype=GRB.INTEGER, name="L")  # Long cables
S = model.addVar(vtype=GRB.INTEGER, name="S")  # Short cables

# Define the constraints
model.addConstr(GoldPerLongCable * L + GoldPerShortCable * S <= TotalGoldAvailable, "GoldConstraint")
model.addConstr(S >= ShortCableRequirement * L, "ShortCableRequirement")
model.addConstr(L >= MinLongCables, "MinLongCables")
model.addConstr(L >= 0, "NonNegLong")
model.addConstr(S >= 0, "NonNegShort")

# Define the objective
model.setObjective(ProfitPerLongCable * L + ProfitPerShortCable * S, GRB.MAXIMIZE)

# Optimize the model
model.optimize()

# Output optimal objective value
if model.status == GRB.OPTIMAL:
    print("Optimal Objective Value: ", model.objVal)
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
else:
    print("Model is not optimal. Status: ", model.status)
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))