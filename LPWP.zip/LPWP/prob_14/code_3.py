import os
import numpy as np
from gurobipy import Model, GRB

# Define the parameters
TotalGoldAvailable = 1000
GoldLongCable = 10
GoldShortCable = 7
RatioShortLong = 5
MinimumLongCables = 10
ProfitLongCable = 12
ProfitShortCable = 5

# Create the model
model = Model("OptimizationProblem")

# Define the variables
NumberLongCables = model.addVar(vtype=GRB.INTEGER, name="NumberLongCables")
NumberShortCables = model.addVar(vtype=GRB.INTEGER, name="NumberShortCables")

# Define the constraints
model.addConstr(NumberShortCables >= RatioShortLong * NumberLongCables)
model.addConstr(NumberLongCables >= MinimumLongCables)
model.addConstr(GoldLongCable * NumberLongCables + GoldShortCable * NumberShortCables <= TotalGoldAvailable)

# Set the objective function
model.setObjective(ProfitLongCable * NumberLongCables + ProfitShortCable * NumberShortCables, GRB.MAXIMIZE)

# Solve the model
model.optimize()

# Print the optimal objective value
if model.status == GRB.OPTIMAL:
    print("Optimal Objective Value: ", model.objVal)
else:
    print("Optimal solution not found.")