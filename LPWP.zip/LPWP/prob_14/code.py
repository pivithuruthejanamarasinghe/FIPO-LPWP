
            import os
            import numpy as np
            import json 
            from gurobipy import Model, GRB, quicksum


            model = Model("OptimizationProblem")

            with open("data.json", "r") as f:
                data = json.load(f)

        


### Define the parameters

TotalGoldAvailable = data["TotalGoldAvailable"] # shape: [], definition: The total amount of gold available in mg to produce cables

GoldPerLongCable = data["GoldPerLongCable"] # shape: [], definition: The amount of gold in mg required to produce one long cable

GoldPerShortCable = data["GoldPerShortCable"] # shape: [], definition: The amount of gold in mg required to produce one short cable

MinLongCables = data["MinLongCables"] # shape: [], definition: The minimum number of long cables that must be produced

ProfitPerLongCable = data["ProfitPerLongCable"] # shape: [], definition: The profit earned from selling one long cable

ProfitPerShortCable = data["ProfitPerShortCable"] # shape: [], definition: The profit earned from selling one short cable

ShortCableRequirement = data["ShortCableRequirement"] # shape: [], definition: The required ratio of short cables to long cables (at least 5 times more short cables than long cables)



### Define the variables

L = model.addVar(vtype=GRB.INTEGER, name="L")

S = model.addVar(vtype=GRB.INTEGER, name="S")



### Define the constraints

model.addConstr(10 * L + 7 * S <= TotalGoldAvailable)
model.addConstr(S >= 5 * L)
model.addConstr(L >= 10)
model.addConstr(L >= 0)
model.addConstr(S >= 0)


### Define the objective

model.setObjective(12 * L + 5 * S, GRB.MAXIMIZE)


### Optimize the model

model.optimize()



### Output optimal objective value

print("Optimal Objective Value: ", model.objVal)


            if model.status == GRB.OPTIMAL:
                with open("output_solution.txt", "w") as f:
                    f.write(str(model.objVal))
                print("Optimal Objective Value: ", model.objVal)
            else:
                with open("output_solution.txt", "w") as f:
                    f.write(model.status)
        