# Import necessary libraries
from gurobipy import Model, GRB

def prob_113(children_vaccines, adult_vaccines):
    """
    Args:
        children_vaccines: an integer representing the number of mRNA milligrams in a children's vaccine
        adult_vaccines: an integer representing the number of mRNA milligrams in an adult vaccine

    Returns:
        obj: an integer representing the objective value (amount of fever suppressant)
    """
    # Create a new model
    m = Model("vaccine_production")

    # Define variables
    x = m.addVar(name="children_vaccines")
    y = m.addVar(name="adult_vaccines")

    # Set objective function
    m.setObjective(x + y, GRB.MINIMIZE)

    # Add constraints
    m.addConstr(50 * x + 75 * y <= 20000, "mRNA_constraint")  # Total mRNA constraint
    m.addConstr(y >= 0.7 * (x + y), "adult_vaccine_percentage")  # At least 70% adult vaccines
    m.addConstr(x >= 50, "minimum_children_vaccines")  # At least 50 children's vaccines

    # Solve the model
    m.optimize()

    # Get the objective value
    obj = m.objVal

    return int(obj)