
def prob_128(liquid_hand_sanitizer, foam_hand_sanitizer):
    """
    Args:
        liquid_hand_sanitizer: an integer, the number of water units needed for a liquid hand sanitizer
        foam_hand_sanitizer: an integer, the number of water units needed for a foam hand sanitizer

    Returns:
        obj: an integer, the maximum number of hands that can be cleaned
    """
    obj = 1e9
    # To be implemented
    return obj
