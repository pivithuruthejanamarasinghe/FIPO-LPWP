# Import necessary libraries
from gurobipy import Model, GRB

def prob_128(liquid_hand_sanitizer, foam_hand_sanitizer):
    """
    Args:
        liquid_hand_sanitizer: an integer, the number of water units needed for a liquid hand sanitizer
        foam_hand_sanitizer: an integer, the number of water units needed for a foam hand sanitizer

    Returns:
        obj: an integer, the maximum number of hands that can be cleaned
    """
    # Create a new model
    m = Model("hand_sanitizer_production")

    # Define variables
    x = m.addVar(name="liquid_hand_sanitizer")
    y = m.addVar(name="foam_hand_sanitizer")

    # Set objective function (maximize the number of hands cleaned)
    m.setObjective(30 * x + 20 * y, GRB.MAXIMIZE)

    # Add constraints
    m.addConstr(40 * x + 60 * y <= 2000, "water_constraint")  # Water constraint
    m.addConstr(50 * x + 40 * y <= 2100, "alcohol_constraint")  # Alcohol constraint
    m.addConstr(y > x, "foam_greater_than_liquid")  # Foam must exceed liquid
    m.addConstr(x <= 30, "liquid_limit")  # At most 30 liquid hand sanitizers

    # Solve the model
    m.optimize()

    # Get the optimal solution
    obj = int(m.objVal)

    return obj