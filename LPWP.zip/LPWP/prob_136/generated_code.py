# Import necessary libraries
from gurobipy import Model, GRB

def prob_136(lab_1, lab_2):
    """
    Solves the optimization problem using Gurobi.
    
    Args:
        lab_1: an integer representing the number of labor hours needed to run a session at lab 1
        lab_2: an integer representing the number of labor hours needed to run a session at lab 2
    
    Returns:
        obj: an integer representing the total time needed
    """
    # Create a new model
    m = Model("medication_production")
    
    # Add variables
    x = m.addVar(name="lab_1_hours", vtype=GRB.CONTINUOUS)
    y = m.addVar(name="lab_2_hours", vtype=GRB.CONTINUOUS)
    
    # Set objective function
    m.setObjective(x + y, GRB.MINIMIZE)
    
    # Add constraints
    m.addConstr(20 * x + 30 * y >= 20000, "heart_medication_constraint")
    m.addConstr(30 * x + 40 * y >= 30000, "lung_medication_constraint")
    m.addConstr(3 * x + 5 * y <= 1500, "labor_hours_constraint")
    
    # Solve the model
    m.optimize()
    
    # Get the optimal solution
    obj = m.objVal
    
    return int(obj)

# Example usage
print(prob_136(3, 5))