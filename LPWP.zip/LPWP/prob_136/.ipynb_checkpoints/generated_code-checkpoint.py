   You can use the following code to solve the problem:
                    
import numpy as np
from scipy.optimize import minimize

def prob_136(constraint1, constraint2, constraint3):
    # Objective function
    def obj(x):
        lab_1, lab_2 = x
        heart_pills = 20*lab_1 + 30*lab_2
        lung_pills = 30*lab_1 + 40*lab_2
        time = 3*lab_1 + 5*lab_2
        return time

    # Constraints
    def constraint1(x):
        lab_1, lab_2 = x
        return constraint1 - (3*lab_1 + 5*lab_2)

    def constraint2(x):
        lab_1, lab_2 = x
        return constraint2 - (20*lab_1 + 30*lab_2)

    def constraint3(x):
        lab_1, lab_2 = x
        return constraint3 - (30*lab_1 + 40*lab_2)

    # Bounds
    bounds = [(0, None), (0, None)]

    # Initial guess
    x0 = [0, 0]

    # Optimization
    result = minimize(obj, x0, bounds=bounds, constraints=[constraint1, constraint2, constraint3])

    # Return the total time needed
    return result.fun

# Example usage
constraint1 = 1500
constraint2 = 20000
constraint3 = 30000
total_time = prob_136(constraint1, constraint2, constraint3)
print(f"Total time needed: {total_time}")

