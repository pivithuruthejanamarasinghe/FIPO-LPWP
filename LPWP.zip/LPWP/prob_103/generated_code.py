from gurobipy import Model, GRB

def prob_103(small_bone, large_bone):
    """
    Args:
        small_bone: an integer, number of meat units needed for a small bone.
        large_bone: an integer, number of meat units needed for a large bone.

    Returns:
        amount_of_meat: an integer.
    """
    # Create a new model
    m = Model("bone_production")

    # Create variables
    x = m.addVar(name="small_bones")
    y = m.addVar(name="large_bones")

    # Set objective function
    m.setObjective(12 * x + 15 * y, GRB.MINIMIZE)

    # Add constraints
    m.addConstr(x >= 0.5 * (x + y), "small_bone_percentage")
    m.addConstr(y >= 30, "minimum_large_bones")
    m.addConstr(10 * x + 15 * y <= 2000, "medication_limit")

    # Solve the model
    m.optimize()

    # Get the optimal values
    small_bones_optimal = x.x
    large_bones_optimal = y.x

    # Calculate the total amount of meat needed
    amount_of_meat = 12 * small_bones_optimal + 15 * large_bones_optimal

    return int(amount_of_meat)