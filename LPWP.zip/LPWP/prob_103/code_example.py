
def prob_103(small_bone, large_bone):
    """
    Args:
        small_bone: an integer, number of meat units needed for a small bone.
        large_bone: an integer, number of meat units needed for a large bone.

    Returns:
        amount_of_meat: an integer.
    """
    obj = 1e9
    # To be implemented
    return obj
