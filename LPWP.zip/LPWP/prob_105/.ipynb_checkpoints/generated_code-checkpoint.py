   You need to implement the logic inside the function to solve the problem.
                   The objective is to minimize the total time it takes for a house to be cleaned.
                   The constraints are:
                   - At least 100 units of the cleansing chemical must be used.
                   - The total units of chemicals used must be at least 300.
                   - The amount of cleansing chemical must be at most twice the amount of odor-removing chemical.
                   
                   The time it takes for each unit of the cleansing chemical to be effective is 4 units, and for each unit of the odor-removing chemical, it takes 6 minutes.
                   
                   The function should return the minimum total time it takes for a house to be cleaned, given the constraints.
                   
                   Note: You can use any optimization library or method to solve this problem.
                   
                   Example:
                   >>> prob_105(100, 50)
                   300
                   
                   In this example, the minimum total time it takes for a house to be cleaned is 300 minutes, given that 100 units of the cleansing chemical and 50 units of the odor-removing chemical are used.
                   
                   You can assume that the input values are valid and within the constraints.
                   
                   You can use the following code to get started:
                   
import numpy as np
from scipy.optimize import minimize

def prob_105(cleansing_chemical, odor_removing_chemical):
    """
    Args:
        cleansing_chemical: an integer, the units of cleansing chemical used
        odor_removing_chemical: an integer, the units of odor-removing chemical used
    Returns:
        obj: an integer, the total time it takes for a house to be cleaned
    """
    # Define the objective function
    def obj_func(x):
        cleansing_chemical, odor_removing_chemical = x
        time_cleansing_chemical = cleansing_chemical * 4
        time_odor_removing_chemical = odor_removing_chemical * 6
        total_time = time_cleansing_chemical + time_odor_removing_chemical
        return total_time
    
    # Define the constraints
    constraints = [
        {'type': 'ineq', 'fun': lambda x: x[0] - 100},
        {'type': 'ineq', 'fun': lambda x: 300 - (x[0] + x[1])},
        {'type': 'ineq', 'fun': lambda x: x[0] - 2 * x[1]}
    ]
    
    # Define the bounds
    bounds = [(100, None), (0, None)]
    
    # Solve the optimization problem
    result = minimize(obj_func, [cleansing_chemical, odor_removing_chemical], method='SLSQP', bounds=bounds, constraints=constraints)
    
    # Return the minimum total time
    return int(result.fun)

