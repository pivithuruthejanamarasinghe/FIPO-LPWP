# Import necessary libraries
from gurobipy import Model, GRB

def prob_105(cleansing_chemical, odor_removing_chemical):
    """
    Solves the optimization problem using Gurobi.
    
    Args:
        cleansing_chemical: an integer, amount of time needed for one unit of cleansing chemical to be effective
        odor_removing_chemical: an integer, amount of time needed for one unit of odor-removing chemical to be effective
    
    Returns:
        obj: an integer, the total time it takes for a house to be cleaned
    """
    # Create a new model
    model = Model("cleaning_problem")
    
    # Add variables
    x = model.addVar(name="cleansing_chemical", vtype=GRB.CONTINUOUS)
    y = model.addVar(name="odor_removing_chemical", vtype=GRB.CONTINUOUS)
    
    # Set objective function
    model.setObjective(x * cleansing_chemical + y * odor_removing_chemical, GRB.MINIMIZE)
    
    # Add constraints
    model.addConstr(x >= 100, "minimum_cleansing_chemical")
    model.addConstr(x + y <= 300, "total_chemicals")
    model.addConstr(x <= 2 * y, "cleansing_to_odor_ratio")
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    obj = model.objVal
    
    return int(obj)

# Example usage
print(prob_105(4, 6))