
def prob_106(factory_1, factory_2):
    """
    Args:
        factory_1: an integer, number of rare compound units needed for factory 1
        factory_2: an integer, number of rare compound units needed for factory 2

    Returns:
        obj: a float, the minimum total time needed
    """
    obj = 1e9
    # To be implemented
    return obj
