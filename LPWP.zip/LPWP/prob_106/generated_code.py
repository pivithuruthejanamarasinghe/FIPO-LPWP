't forget to import any necessary libraries.

Here is a solution using Gurobi: