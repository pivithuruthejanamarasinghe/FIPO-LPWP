
def prob_127(cashews, almonds):
    """
    Args:
        cashews: an integer, calories in a cashew serving
        almonds: an integer, calories in an almond serving

    Returns:
        obj: an integer
    """
    obj = 1e9
    # To be implemented
    return obj
