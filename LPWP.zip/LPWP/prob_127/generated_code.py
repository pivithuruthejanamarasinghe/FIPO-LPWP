import gurobipy as gp
from gurobipy import GRB

def prob_127(cashews, almonds):
    """
    Args:
        cashews: an integer, calories in a cashew serving
        almonds: an integer, calories in an almond serving

    Returns:
        obj: an integer
    """
    # Create a new model
    model = gp.Model("cashew_almond_optimization")

    # Add variables
    x = model.addVar(name="cashews")
    y = model.addVar(name="almonds")

    # Set objective function (minimize fat)
    model.setObjective(15 * x + 12 * y, GRB.MINIMIZE)

    # Add constraints
    model.addConstr(x >= 0, "non_neg_cashews")
    model.addConstr(y >= 0, "non_neg_almonds")
    model.addConstr(2 * y >= x, "twice_as_many_almonds")
    model.addConstr(300 * x + 200 * y >= 10000, "calories_constraint")
    model.addConstr(25 * x + 20 * y >= 800, "protein_constraint")

    # Solve the model
    model.optimize()

    # Get the optimal values
    obj = model.objVal
    return int(obj)