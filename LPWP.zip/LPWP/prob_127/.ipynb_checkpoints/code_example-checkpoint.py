
def prob_127(cashews, almonds, _200, _20, _300, _25, twice, _15, _12, _10000, _800):
    """
    Args:
        cashews: an integer
        almonds: an integer
        _200: an integer
        _20: an integer
        _300: an integer
        _25: an integer
        twice: an integer
        _15: an integer
        _12: an integer
        _10000: an integer
        _800: an integer
    Returns:
        obj: an integer
    """
    obj = 1e9
    # To be implemented
    return obj
