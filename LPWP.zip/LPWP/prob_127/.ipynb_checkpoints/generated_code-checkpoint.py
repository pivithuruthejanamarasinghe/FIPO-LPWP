from pulp import *

def prob_127(cashews, almonds, _200, _20, _300, _25, twice, _15, _12, _10000, _800):
    # Create the problem variable
    prob = LpProblem("Minimize Fat Intake", LpMinimize)

    # Create the decision variables
    cashews_vars = LpVariable("cashews", lowBound=0, cat='Integer')
    almonds_vars = LpVariable("almonds", lowBound=0, cat='Integer')

    # Create the objective function
    prob += _15 * almonds_vars + _12 * cashews_vars, "Total Fat Intake"

    # Create the calorie constraint
    prob += _200 * almonds_vars + _300 * cashews_vars >= _10000

    # Create the protein constraint
    prob += _20 * almonds_vars + _25 * cashews_vars >= _800

    # Create the constraint for twice as many servings of almonds as cashews
    prob += almonds_vars >= 2 * cashews_vars

    # Solve the problem
    prob.solve()

    # Print the results
    print("Number of servings of cashews:", int(cashews_vars.varValue))
    print("Number of servings of almonds:", int(almonds_vars.varValue))
    print("Total Fat Intake:", _15 * almonds_vars.varValue + _12 * cashews_vars.varValue)

    return prob.objective()

# Example usage
prob_127(cashews=0, almonds=0, _200=200, _20=20, _300=300, _25=25, twice=2, _15=15, _12=12, _10000=10000, _800=800)