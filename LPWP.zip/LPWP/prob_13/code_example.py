
def prob_13(radio_ads, social_media_ads):
    """
    Args:
        radio_ads: an integer representing the cost of a radio ad
        social_media_ads: an integer representing the cost of a social media ad
    Returns:
        obj: an integer representing the maximum exposure
    """
    obj = 1e9
    # To be implemented
    return obj
