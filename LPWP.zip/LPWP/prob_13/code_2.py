ddress the error you're encountering, it appears that the code is attempting to read a JSON file named "data.json" that does not exist in the specified directory. To resolve this, I'll provide an example of how you can create the necessary JSON file with the required parameters, and also ensure that the code is capable of running without encountering a `FileNotFoundError`.

Here is the corrected code with the inclusion of a sample JSON structure that you can place in the same directory as your script:


import os
import numpy as np
import json 
from gurobipy import Model, GRB, quicksum

# Create a sample data.json file if it does not exist
data_file = "data.json"
if not os.path.isfile(data_file):
    data = {
        "AdvertisingBudget": 250000,
        "RadioAdCost": 5000,
        "SocialMediaAdCost": 9150,
        "RadioAdExposure": 60500,
        "SocialMediaAdExposure": 50000,
        "MinRadioAds": 15,
        "MaxRadioAds": 40,
        "MinSocialMediaAds": 35
    }
    with open(data_file, "w") as f:
        json.dump(data, f)

model = Model("OptimizationProblem")

with open(data_file, "r") as f:
    data = json.load(f)

### Define the parameters
AdvertisingBudget = data["AdvertisingBudget"]  # The total budget available for advertising
RadioAdCost = data["RadioAdCost"]              # The cost of each radio advertisement
SocialMediaAdCost = data["SocialMediaAdCost"]  # The cost of each social media advertisement
RadioAdExposure = data["RadioAdExposure"]      # The expected exposure for each radio advertisement
SocialMediaAdExposure = data["SocialMediaAdExposure"]  # The expected exposure for each social media advertisement
MinRadioAds = data["MinRadioAds"]              # The minimum number of radio advertisements that should be ordered
MaxRadioAds = data["MaxRadioAds"]              # The maximum number of radio advertisements that should be ordered
MinSocialMediaAds = data["MinSocialMediaAds"]  # The minimum number of social media advertisements that should be contracted

### Define the variables
x = model.addVar(vtype=GRB.INTEGER, name="RadioAds")
y = model.addVar(vtype=GRB.INTEGER, name="SocialMediaAds")

### Define the constraints
model.addConstr(RadioAdCost * x + SocialMediaAdCost * y <= AdvertisingBudget)
model.addConstr(x >= MinRadioAds)
model.addConstr(x <= MaxRadioAds)
model.addConstr(y >= MinSocialMediaAds)

### Define the objective
model.setObjective(RadioAdExposure * x + SocialMediaAdExposure * y, GRB.MAXIMIZE)

### Optimize the model
model.optimize()

### Output optimal objective value
if model.status == GRB.OPTIMAL:
    print("Optimal Objective Value: ", model.objVal)
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
else:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))


This correction includes a section that checks if the "data.json" file exists and creates it with the required parameters if it does not. Please ensure you run this script in an environment where the Gurobi optimizer is installed and properly configured