
            import os
            import numpy as np
            import json 
            from gurobipy import Model, GRB, quicksum


            model = Model("OptimizationProblem")

            with open("data.json", "r") as f:
                data = json.load(f)

        


### Define the parameters

AdvertisingBudget = data["AdvertisingBudget"] # shape: [], definition: The total budget available for advertising

RadioAdCost = data["RadioAdCost"] # shape: [], definition: The cost of each radio advertisement

SocialMediaAdCost = data["SocialMediaAdCost"] # shape: [], definition: The cost of each social media advertisement

RadioAdExposure = data["RadioAdExposure"] # shape: [], definition: The expected exposure (number of viewers) for each radio advertisement

SocialMediaAdExposure = data["SocialMediaAdExposure"] # shape: [], definition: The expected exposure (number of viewers) for each social media advertisement

MinRadioAds = data["MinRadioAds"] # shape: [], definition: The minimum number of radio advertisements that should be ordered

MaxRadioAds = data["MaxRadioAds"] # shape: [], definition: The maximum number of radio advertisements that should be ordered

MinSocialMediaAds = data["MinSocialMediaAds"] # shape: [], definition: The minimum number of social media advertisements that should be contracted



### Define the variables

x = model.addVar(vtype=GRB.INTEGER, name="x")

y = model.addVar(vtype=GRB.INTEGER, name="y")



### Define the constraints

model.addConstr(5000 * x + 9150 * y <= AdvertisingBudget)
model.addConstr(x >= 15)
model.addConstr(x <= 40)
model.addConstr(y >= 35)
model.addConstr(x >= 0)
model.addConstr(y >= 0)


### Define the objective

model.setObjective(60500 * x + 50000 * y, GRB.MAXIMIZE)


### Optimize the model

model.optimize()



### Output optimal objective value

print("Optimal Objective Value: ", model.objVal)


            if model.status == GRB.OPTIMAL:
                with open("output_solution.txt", "w") as f:
                    f.write(str(model.objVal))
                print("Optimal Objective Value: ", model.objVal)
            else:
                with open("output_solution.txt", "w") as f:
                    f.write(model.status)
        