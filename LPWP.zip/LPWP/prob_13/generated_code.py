# Importing the Gurobi library
from gurobipy import Model, GRB

def prob_13(radio_ads, social_media_ads):
    """
    Solves the optimization problem using Gurobi.
    
    Args:
        radio_ads: an integer representing the cost of a radio ad
        social_media_ads: an integer representing the cost of a social media ad
    
    Returns:
        obj: an integer representing the maximum exposure
    """
    # Create a new model
    m = Model("advertising_optimization")
    
    # Add variables
    x = m.addVar(vtype=GRB.INTEGER, name="radio_ads")
    y = m.addVar(vtype=GRB.INTEGER, name="social_media_ads")
    
    # Set objective
    m.setObjective(60500 * x + 50000 * y, GRB.MAXIMIZE)
    
    # Add constraints
    m.addConstr(x >= 15, "min_radio_ads")
    m.addConstr(x <= 40, "max_radio_ads")
    m.addConstr(y >= 35, "min_social_media_ads")
    m.addConstr(radio_ads * x + social_media_ads * y <= 250000, "budget_constraint")
    
    # Solve the model
    m.optimize()
    
    # Get the optimal solution
    obj = int(m.objVal)
    
    return obj