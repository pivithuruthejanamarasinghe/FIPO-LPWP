import os
import numpy as np
import json 
from gurobipy import Model, GRB, quicksum

model = Model("OptimizationProblem")

with open("data.json", "r") as f:
    data = json.load(f)

### Define the parameters
AdvertisingBudget = data["AdvertisingBudget"]  # The total budget available for advertising
RadioAdCost = data["RadioAdCost"]              # The cost of each radio advertisement
SocialMediaAdCost = data["SocialMediaAdCost"]  # The cost of each social media advertisement
RadioAdExposure = data["RadioAdExposure"]      # The expected exposure for each radio advertisement
SocialMediaAdExposure = data["SocialMediaAdExposure"]  # The expected exposure for each social media advertisement
MinRadioAds = data["MinRadioAds"]              # The minimum number of radio advertisements that should be ordered
MaxRadioAds = data["MaxRadioAds"]              # The maximum number of radio advertisements that should be ordered
MinSocialMediaAds = data["MinSocialMediaAds"]  # The minimum number of social media advertisements that should be contracted

### Define the variables
x = model.addVar(vtype=GRB.INTEGER, name="RadioAds")
y = model.addVar(vtype=GRB.INTEGER, name="SocialMediaAds")

### Define the constraints
model.addConstr(RadioAdCost * x + SocialMediaAdCost * y <= AdvertisingBudget)
model.addConstr(x >= MinRadioAds)
model.addConstr(x <= MaxRadioAds)
model.addConstr(y >= MinSocialMediaAds)

### Define the objective
model.setObjective(RadioAdExposure * x + SocialMediaAdExposure * y, GRB.MAXIMIZE)

### Optimize the model
model.optimize()

### Output optimal objective value
if model.status == GRB.OPTIMAL:
    print("Optimal Objective Value: ", model.objVal)
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
else:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))