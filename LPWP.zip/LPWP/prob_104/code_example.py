
def prob_104(orange_juice):
    """
    Args:
        orange_juice: an integer (minimum number of orange juice boxes)
    Returns:
        objective_value: an integer (total vitamin D intake)
    """
    objective_value = 1e9
    # To be implemented
    return objective_value
