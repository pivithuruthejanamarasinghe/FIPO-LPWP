# Import necessary libraries
from gurobipy import Model, GRB

def prob_104(orange_juice):
    """
    Solves the vitamin intake optimization problem using Gurobi.
    
    Args:
        orange_juice: an integer (minimum number of orange juice boxes)
        
    Returns:
        objective_value: an integer (total vitamin D intake)
    """
    # Create a new model
    model = Model("vitamin_intake")
    
    # Define variables
    orange_juice_var = model.addVar(name="orange_juice", vtype=GRB.INTEGER, lb=orange_juice)
    apple_juice_var = model.addVar(name="apple_juice", vtype=GRB.INTEGER, lb=3 * orange_juice_var)
    
    # Set objective function
    model.setObjective(10 * orange_juice_var + 12 * apple_juice_var, GRB.MAXIMIZE)
    
    # Add constraints
    model.addConstr(8 * orange_juice_var + 6 * apple_juice_var <= 300, "vitamin_C_constraint")
    
    # Solve the model
    model.optimize()
    
    # Get the objective value
    objective_value = model.objVal
    
    return int(objective_value)

# Example usage
print(prob_104(3))