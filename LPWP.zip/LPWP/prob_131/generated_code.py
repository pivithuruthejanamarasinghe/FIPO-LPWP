# Import necessary libraries
from gurobipy import Model, GRB

def prob_131(calories, potassium):
    """
    Solves the gorilla feeding problem using linear programming.
    
    Args:
        calories: an integer, minimum number of calories
        potassium: an integer, minimum number of potassium
        
    Returns:
        obj: an integer, minimum sugar intake
    """
    # Create a new model
    model = Model("gorilla_feeding")
    
    # Define variables
    x = model.addVar(name="bananas")  # Number of bananas
    y = model.addVar(name="mangoes")   # Number of mangoes
    
    # Set objective function (minimize sugar intake)
    model.setObjective(10 * x + 8 * y, GRB.MINIMIZE)  # Sugar content per fruit
    
    # Add constraints
    model.addConstr(80 * x + 100 * y >= calories, "calories_constraint")  # Minimum calories
    model.addConstr(20 * x + 15 * y >= potassium, "potassium_constraint")  # Minimum potassium
    model.addConstr(y <= 0.33 * (x + y), "mango_percentage_constraint")  # Maximum mango percentage
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    obj = model.objVal
    
    return int(obj)

# Example usage
print(prob_131(4000, 150))