from pulp import LpProblem, LpMaximize, LpVariable, lpSum, LpStatus

def prob_119(electronic_thermometer, regular_thermometer, electronic_constraint, regular_constraint, time_constraint):
    """
    Args:
        electronic_thermometer: an integer representing the number of patients checked with the electronic thermometer
        regular_thermometer: an integer representing the number of patients checked with the regular thermometer
        electronic_constraint: an integer representing the required number of patients checked with the electronic thermometer
        regular_constraint: an integer representing the required number of patients checked with the regular thermometer
        time_constraint: an integer representing the maximum time the office is open
    Returns:
        number_of_patients: an integer representing the maximum number of patients whose temperature can be taken
    """
    # Define the problem
    prob = LpProblem("Maximize_Patients", LpMaximize)

    # Declare decision variables
    t_electronic = LpVariable('t_electronic', lowBound=0, cat='Integer')
    t_regular = LpVariable('t_regular', lowBound=0, cat='Integer')

    # Formulate the objective function
    prob += t_electronic + t_regular

    # Add constraints
    prob += t_electronic >= electronic_constraint
    prob += t_regular >= regular_constraint
    prob += t_electronic * 3 + t_regular * 2 <= time_constraint

    # Solve the problem
    prob.solve()

    # Check the solution status
    assert LpStatus[prob.status] == 'Optimal', "The problem does not have an optimal solution."

    # Retrieve and return results
    number_of_patients = t_electronic.value() + t_regular.value()
    print(f"Optimal number of patients: {number_of_patients}")
    return int(number_of_patients)

# Example usage
electronic_thermometer = 50
regular_thermometer = 50
electronic_constraint = 2 * regular_thermometer
regular_constraint = 50
time_constraint = 15000

prob_119(electronic_thermometer, regular_thermometer, electronic_constraint, regular_constraint, time_constraint)