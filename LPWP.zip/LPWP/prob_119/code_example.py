
def prob_119(electronic_thermometer, regular_thermometer):
    """
    Args:
        electronic_thermometer: an integer representing the number of minutes taken by an electronic thermometer to check a patient
        regular_thermometer: an integer representing the number of minutes taken by a regular thermometer to check a patient
    Returns:
        number_of_patients: an integer representing the maximum number of patients whose temperature can be taken
    """
    number_of_patients = 1e9
    # To be implemented
    return number_of_patients
