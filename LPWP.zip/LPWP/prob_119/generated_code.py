constraints are:

1. At least twice as many patients should have their temperature checked by the electronic thermometer than the regular thermometer.
2. At least 50 patients should have their temperature checked by a regular thermometer.
3. The office is open for 15000 minutes.

Here is a possible solution using Gurobi: