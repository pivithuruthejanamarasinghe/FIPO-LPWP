
def prob_117(burgers, pizza):
    """
    Args:
        burgers: an integer, the number of calories in a burger
        pizza: an integer, the number of calories in a pizza slice
    Returns:
        obj: an integer, the objective value (cholesterol intake)
    """
    obj = 1e9
    # To be implemented
    return obj
