# Import necessary libraries
from gurobipy import Model, GRB

def prob_117(burgers, pizza):
    """
    Solves the optimization problem using Gurobi.
    
    Args:
        burgers: an integer, the number of calories in a burger
        pizza: an integer, the number of calories in a pizza slice
        
    Returns:
        obj: an integer, the objective value (cholesterol intake)
    """
    # Create a new model
    model = Model("weight_gain")
    
    # Add variables
    x = model.addVar(name="burgers", vtype=GRB.INTEGER)
    y = model.addVar(name="pizza", vtype=GRB.INTEGER)
    
    # Set objective function
    model.setObjective(12 * x + 10 * y, GRB.MINIMIZE)  # Minimize cholesterol intake
    
    # Add constraints
    model.addConstr(10 * x + 8 * y >= 130, "fat_constraint")  # At least 130 units of fat
    model.addConstr(300 * x + 250 * y >= 3000, "calories_constraint")  # At least 3000 calories
    model.addConstr(y >= 2 * x, "pizza_to_burger_ratio")  # At least twice as many slices of pizza as burgers
    
    # Solve the model
    model.optimize()
    
    # Get the optimal values
    obj = model.objVal
    
    return int(obj)

# Example usage
print(prob_117(10, 8))