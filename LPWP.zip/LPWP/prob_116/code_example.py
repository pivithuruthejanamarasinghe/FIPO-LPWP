
def prob_116(factory_1, factory_2):
    """
    Args:
        factory_1: an integer, units of base gel required for factory 1 per hour
        factory_2: an integer, units of base gel required for factory 2 per hour

    Returns:
        total_time: a float, total time needed to minimize the total time
    """
    total_time = 1e9
    # To be implemented
    return total_time
