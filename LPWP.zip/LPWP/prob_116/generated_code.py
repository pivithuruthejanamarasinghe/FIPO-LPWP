# Importing the Gurobi library
from gurobipy import Model, GRB

def prob_116(factory_1, factory_2):
    """
    Calculates the minimum total time required to produce the required amount of creams using both factories.

    Args:
        factory_1: an integer, units of base gel required for factory 1 per hour
        factory_2: an integer, units of base gel required for factory 2 per hour

    Returns:
        total_time: a float, total time needed to minimize the total time
    """

    # Create a new model
    m = Model("factory_production")

    # Define variables
    x = m.addVar(name="hours_factory_1")
    y = m.addVar(name="hours_factory_2")

    # Set objective function (minimize total time)
    m.setObjective(x + y, GRB.MINIMIZE)

    # Add constraints
    m.addConstr(12 * x + 20 * y >= 800, "acne_cream_constraint")  # At least 800 units of acne cream
    m.addConstr(15 * x + 10 * y >= 1000, "anti_bacterial_cream_constraint")  # At least 1000 units of anti-bacterial cream
    m.addConstr(30 * x + 45 * y <= 5000, "base_gel_constraint")  # Available base gel constraint

    # Solve the model
    m.optimize()

    # Get the optimal solution
    total_time = x.x + y.x

    return total_time