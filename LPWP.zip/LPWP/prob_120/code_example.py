
def prob_120(machine_1, machine_2):
    """
    Args:
        machine_1: a float, the waste of machine 1 per minute
        machine_2: a float, the waste of machine 2 per minute
    Returns:
        Total_Amount_of_Waste: a float, the total amount of waste produced
    """
    Total_Amount_of_Waste = 1e9
    # To be implemented
    return Total_Amount_of_Waste
