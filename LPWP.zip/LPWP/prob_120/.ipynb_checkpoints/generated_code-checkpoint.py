from pulp import LpProblem, LpMinimize, LpVariable, lpSum

def prob_120(machine_1, machine_2):
    """
    Args:
        machine_1: a float, the usage of machine 1 in minutes
        machine_2: a float, the usage of machine 2 in minutes
    Returns:
        Total_Amount_of_Waste: a float, the total amount of waste produced
    """
    # Define the problem
    prob = LpProblem("Minimize_Waste", LpMinimize)

    # Declare decision variables
    waste_machine_1 = LpVariable('waste_machine_1', lowBound=0, cat='Continuous')
    waste_machine_2 = LpVariable('waste_machine_2', lowBound=0, cat='Continuous')

    # Formulate the objective function
    waste_per_minute_machine_1 = 0.3
    waste_per_minute_machine_2 = 0.5
    total_waste = lpSum([waste_machine_1, waste_machine_2])
    prob += total_waste

    # Add constraints
    heart_medicine_machine_1 = 0.5 * machine_1
    heart_medicine_machine_2 = 0.3 * machine_2
    brain_medicine_machine_1 = 0.8 * machine_1
    brain_medicine_machine_2 = 1 * machine_2
    heart_medicine_constraint = heart_medicine_machine_1 + heart_medicine_machine_2 <= 8
    brain_medicine_constraint = brain_medicine_machine_1 + brain_medicine_machine_2 >= 4

    prob += heart_medicine_constraint
    prob += brain_medicine_constraint

    # Solve the problem
    prob.solve()

    # Check if a solution exists
    if prob.status == 1:
        # Retrieve and return results
        Total_Amount_of_Waste = waste_machine_1.varValue + waste_machine_2.varValue
        print(f"Machine 1 usage (minutes): {machine_1}")
        print(f"Machine 2 usage (minutes): {machine_2}")
        print(f"Total waste produced: {Total_Amount_of_Waste}")
        return Total_Amount_of_Waste
    else:
        raise ValueError("No feasible solution found.")

# Example usage
try:
    prob_120(machine_1=4, machine_2=4)
except ValueError as e:
    print(e)