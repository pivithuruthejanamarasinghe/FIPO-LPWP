# Import necessary libraries
from gurobipy import Model, GRB

def prob_120(machine_1, machine_2):
    """
    Calculates the optimal usage time for two machines to minimize waste production,
    given constraints on heart and brain medicine delivery.
    
    Args:
        machine_1: a float, the waste of machine 1 per minute
        machine_2: a float, the waste of machine 2 per minute
    
    Returns:
        Total_Amount_of_Waste: a float, the total amount of waste produced
    """
    # Create a new model
    m = Model("waste_minimization")
    
    # Define variables
    x = m.addVar(name="time_machine_1")  # Time machine 1 is used
    y = m.addVar(name="time_machine_2")  # Time machine 2 is used
    
    # Set objective function (minimize total waste)
    m.setObjective(x * machine_1 + y * machine_2, GRB.MINIMIZE)
    
    # Add constraints
    m.addConstr(0.5 * x + 0.3 * y <= 8, "heart_constraint")  # Heart medicine constraint
    m.addConstr(0.8 * x + 1.0 * y >= 4, "brain_constraint")  # Brain medicine constraint
    
    # Solve the model
    m.optimize()
    
    # Get the solution values
    Total_Amount_of_Waste = m.objVal
    
    return Total_Amount_of_Waste