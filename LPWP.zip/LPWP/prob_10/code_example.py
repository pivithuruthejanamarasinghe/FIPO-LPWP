
def prob_10(nitrogen, phosphoric_acid, vitamin_A):
    """
    Args:
        nitrogen: an integer, minimum units of nitrogen needed
        phosphoric_acid: an integer, minimum units of phosphoric acid needed
        vitamin_A: an integer, minimum units of vitamin A needed
    Returns:
        obj: an integer, amount of vitamin D
    """
    obj = 1e9
    # To be implemented
    return obj
