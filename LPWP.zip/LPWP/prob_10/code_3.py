import os
import numpy as np
import json 
from gurobipy import Model, GRB, quicksum

model = Model("OptimizationProblem")

# Define the data directly in the code instead of loading from a JSON file
UnitsOfNitrogenFertilizerA = 13
UnitsOfPhosphoricAcidFertilizerA = 5
UnitsOfVitaminAFertilizerA = 6
UnitsOfVitaminDFertilizerA = 5
UnitsOfNitrogenFertilizerB = 8
UnitsOfPhosphoricAcidFertilizerB = 14
UnitsOfVitaminAFertilizerB = 6
UnitsOfVitaminDFertilizerB = 9
MinimumUnitsOfNitrogen = 220
MinimumUnitsOfPhosphoricAcid = 160
MaximumUnitsOfVitaminA = 350

x = model.addVar()
y = model.addVar()

model.addConstr(UnitsOfVitaminAFertilizerA * x + UnitsOfVitaminAFertilizerB * y <= MaximumUnitsOfVitaminA)
model.addConstr(UnitsOfNitrogenFertilizerA * x + UnitsOfNitrogenFertilizerB * y >= MinimumUnitsOfNitrogen)
model.addConstr(UnitsOfPhosphoricAcidFertilizerA * x + UnitsOfPhosphoricAcidFertilizerB * y >= MinimumUnitsOfPhosphoricAcid)
model.addConstr(x >= 0)
model.addConstr(y >= 0)

model.setObjective(UnitsOfVitaminDFertilizerA * x + UnitsOfVitaminDFertilizerB * y, GRB.MINIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
    print("Optimal Objective Value: ", model.objVal)
else:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))