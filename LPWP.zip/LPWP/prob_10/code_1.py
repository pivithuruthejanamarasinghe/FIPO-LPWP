import os
import numpy as np
import json 
from gurobipy import Model, GRB, quicksum

model = Model("OptimizationProblem")

with open("data.json", "r") as f:
    data = json.load(f)

# Define the parameters

UnitsOfNitrogenFertilizerA = data["UnitsOfNitrogenFertilizerA"] # shape: [], definition: Units of nitrogen in 1 kg of fertilizer A
UnitsOfPhosphoricAcidFertilizerA = data["UnitsOfPhosphoricAcidFertilizerA"] # shape: [], definition: Units of phosphoric acid in 1 kg of fertilizer A
UnitsOfVitaminAFertilizerA = data["UnitsOfVitaminAFertilizerA"] # shape: [], definition: Units of vitamin A in 1 kg of fertilizer A
UnitsOfVitaminDFertilizerA = data["UnitsOfVitaminDFertilizerA"] # shape: [], definition: Units of vitamin D in 1 kg of fertilizer A
UnitsOfNitrogenFertilizerB = data["UnitsOfNitrogenFertilizerB"] # shape: [], definition: Units of nitrogen in 1 kg of fertilizer B
UnitsOfPhosphoricAcidFertilizerB = data["UnitsOfPhosphoricAcidFertilizerB"] # shape: [], definition: Units of phosphoric acid in 1 kg of fertilizer B
UnitsOfVitaminAFertilizerB = data["UnitsOfVitaminAFertilizerB"] # shape: [], definition: Units of vitamin A in 1 kg of fertilizer B
UnitsOfVitaminDFertilizerB = data["UnitsOfVitaminDFertilizerB"] # shape: [], definition: Units of vitamin D in 1 kg of fertilizer B
MinimumUnitsOfNitrogen = data["MinimumUnitsOfNitrogen"] # shape: [], definition: Minimum required units of nitrogen in plant nutrition
MinimumUnitsOfPhosphoricAcid = data["MinimumUnitsOfPhosphoricAcid"] # shape: [], definition: Minimum required units of phosphoric acid in plant nutrition
MaximumUnitsOfVitaminA = data["MaximumUnitsOfVitaminA"] # shape: [], definition: Maximum allowed units of vitamin A in plant nutrition

# Define the variables
x = model.addVar()
y = model.addVar()

# Define the constraints
model.addConstr(UnitsOfVitaminAFertilizerA * x + UnitsOfVitaminAFertilizerB * y <= MaximumUnitsOfVitaminA)
model.addConstr(UnitsOfNitrogenFertilizerA * x + UnitsOfNitrogenFertilizerB * y >= MinimumUnitsOfNitrogen)
model.addConstr(UnitsOfPhosphoricAcidFertilizerA * x + UnitsOfPhosphoricAcidFertilizerB * y >= MinimumUnitsOfPhosphoricAcid)
model.addConstr(x >= 0)
model.addConstr(y >= 0)

# Define the objective
model.setObjective(UnitsOfVitaminDFertilizerA * x + UnitsOfVitaminDFertilizerB * y, GRB.MINIMIZE)

# Optimize the model
model.optimize()

# Output optimal objective value
if model.status == GRB.OPTIMAL:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
    print("Optimal Objective Value: ", model.objVal)
else:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))
====