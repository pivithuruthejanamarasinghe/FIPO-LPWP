# Import necessary libraries
from gurobipy import Model, GRB

def prob_10(nitrogen, phosphoric_acid, vitamin_A):
    """
    Solves the optimization problem to find the minimum amount of vitamin D in the plant nutrition.
    
    Args:
        nitrogen: an integer, minimum units of nitrogen needed
        phosphoric_acid: an integer, minimum units of phosphoric acid needed
        vitamin_A: an integer, maximum units of vitamin A allowed
    
    Returns:
        obj: an integer, minimum amount of vitamin D
    """
    # Create a new model
    model = Model("plant_nutrition")
    
    # Define variables
    x = model.addVar(name="fertilizer_A", vtype=GRB.CONTINUOUS)
    y = model.addVar(name="fertilizer_B", vtype=GRB.CONTINUOUS)
    
    # Set objective function (minimize vitamin D)
    model.setObjective(5*x + 9*y, GRB.MINIMIZE)
    
    # Add constraints
    model.addConstr(x + y >= 0)  # Non-negativity constraint
    model.addConstr(13*x + 8*y >= nitrogen)  # Nitrogen constraint
    model.addConstr(5*x + 14*y >= phosphoric_acid)  # Phosphoric acid constraint
    model.addConstr(6*x + 6*y <= vitamin_A)  # Vitamin A constraint
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    obj = model.objVal
    
    return int(obj)

# Example usage
print(prob_10(220, 160, 350))