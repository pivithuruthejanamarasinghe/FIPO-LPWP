import os
import numpy as np
import json 
from gurobipy import Model, GRB, quicksum

model = Model("OptimizationProblem")

with open("data.json", "r") as f:
    data = json.load(f)

UnitsOfNitrogenFertilizerA = data["UnitsOfNitrogenFertilizerA"]
UnitsOfPhosphoricAcidFertilizerA = data["UnitsOfPhosphoricAcidFertilizerA"]
UnitsOfVitaminAFertilizerA = data["UnitsOfVitaminAFertilizerA"]
UnitsOfVitaminDFertilizerA = data["UnitsOfVitaminDFertilizerA"]
UnitsOfNitrogenFertilizerB = data["UnitsOfNitrogenFertilizerB"]
UnitsOfPhosphoricAcidFertilizerB = data["UnitsOfPhosphoricAcidFertilizerB"]
UnitsOfVitaminAFertilizerB = data["UnitsOfVitaminAFertilizerB"]
UnitsOfVitaminDFertilizerB = data["UnitsOfVitaminDFertilizerB"]
MinimumUnitsOfNitrogen = data["MinimumUnitsOfNitrogen"]
MinimumUnitsOfPhosphoricAcid = data["MinimumUnitsOfPhosphoricAcid"]
MaximumUnitsOfVitaminA = data["MaximumUnitsOfVitaminA"]

x = model.addVar()
y = model.addVar()

model.addConstr(UnitsOfVitaminAFertilizerA * x + UnitsOfVitaminAFertilizerB * y <= MaximumUnitsOfVitaminA)
model.addConstr(UnitsOfNitrogenFertilizerA * x + UnitsOfNitrogenFertilizerB * y >= MinimumUnitsOfNitrogen)
model.addConstr(UnitsOfPhosphoricAcidFertilizerA * x + UnitsOfPhosphoricAcidFertilizerB * y >= MinimumUnitsOfPhosphoricAcid)
model.addConstr(x >= 0)
model.addConstr(y >= 0)

model.setObjective(UnitsOfVitaminDFertilizerA * x + UnitsOfVitaminDFertilizerB * y, GRB.MINIMIZE)

model.optimize()

if model.status == GRB.OPTIMAL:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.objVal))
    print("Optimal Objective Value: ", model.objVal)
else:
    with open("output_solution.txt", "w") as f:
        f.write(str(model.status))