from pulp import LpProblem, LpMinimize, LpVariable, lpSum, LpStatus

def prob_144():
    """
    Solves the optimization problem of adding chlorine and water softener to a pool
    to minimize the total time it takes for the pool to be ready.

    Returns:
        total_time: an integer representing the minimum total time it takes for the pool to be ready.
        chlorine: an integer representing the optimal number of units of chlorine to be added.
        water_softener: an integer representing the optimal number of units of water softener to be added.
    """
    # Define the problem
    prob = LpProblem("PoolChemicals", LpMinimize)

    # Declare decision variables
    chlorine = LpVariable('chlorine', lowBound=200, cat='Integer')
    water_softener = LpVariable('water_softener', lowBound=0, cat='Integer')

    # Formulate the objective function
    prob += chlorine + 2 * water_softener, "Total Time"

    # Add constraints
    prob += chlorine <= 0.5 * water_softener, "Chlorine_Water_Softener_Constraint"
    prob += chlorine + water_softener == 500, "Total_Chemicals_Constraint"

    # Solve the problem
    prob.solve()

    # Check if a solution exists
    if LpStatus[prob.status] == 'Optimal':
        total_time = chlorine.value() + 2 * water_softener.value()
        return total_time, chlorine.value(), water_softener.value()
    else:
        raise ValueError("No optimal solution found.")

# Call the function and print the results
try:
    total_time, chlorine, water_softener = prob_144()
    print(f"Optimal Total Time: {total_time}")
    print(f"Chlorine Units: {chlorine}")
    print(f"Water Softener Units: {water_softener}")
except ValueError as e:
    print(e)