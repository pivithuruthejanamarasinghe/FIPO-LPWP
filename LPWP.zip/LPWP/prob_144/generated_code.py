# Importing the Gurobi library
from gurobipy import Model, GRB

def prob_144(chlorine, water_softener):
    """
    Solves the optimization problem using Gurobi to minimize the total time it takes for the pool to be ready.
    
    Args:
        chlorine: an integer representing the number of minutes take to be effective
        water_softener: an integer representing the number of minutes take to be effective
    
    Returns:
        total_time: an integer representing the minimum total time it takes for the pool to be ready.
    """
    # Create a new model
    model = Model("pool_chemicals")
    
    # Add variables
    x = model.addVar(name="chlorine_units", vtype=GRB.INTEGER)
    y = model.addVar(name="water_softener_units", vtype=GRB.INTEGER)
    
    # Set objective function
    model.setObjective(x + 2*y, GRB.MINIMIZE)  # Minimize total time
    
    # Add constraints
    model.addConstr(x >= 200, "min_chlorine")  # At least 200 units of chlorine
    model.addConstr(x + y <= 500, "total_chemicals")  # Total of 500 units of chemicals
    model.addConstr(x <= 0.5 * y, "chlorine_water_ratio")  # At most half as much chlorine as water softener
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    total_time = model.objVal
    
    return int(total_time)

# Example usage
print(prob_144(1, 2))