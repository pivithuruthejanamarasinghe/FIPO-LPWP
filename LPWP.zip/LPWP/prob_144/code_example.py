
def prob_144(chlorine, water_softener):
    """
    Args:
        chlorine: an integer representing the number of minutes take to be effective
        water_softener: an integer representing the number of minutes take to be effective
    Returns:
        total_time: an integer representing the minimum total time it takes for the pool to be ready.
    """
    total_time = 1e9
    # To be implemented
    return total_time
