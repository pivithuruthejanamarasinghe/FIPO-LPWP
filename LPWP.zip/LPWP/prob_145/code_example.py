
def prob_145(process_1, process_2):
    """
    Args:
        process_1: an integer, number of units of preliminary materials needed for process 1
        process_2: an integer, number of units of preliminary materials needed for process 2

    Returns:
        obj: an integer, total time needed to minimize
    """
    obj = 1e9
    # To be implemented
    return obj
