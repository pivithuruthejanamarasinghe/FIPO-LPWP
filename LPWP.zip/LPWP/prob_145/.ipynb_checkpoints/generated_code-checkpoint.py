from gurobipy import Model, GRB, quicksum

def prob_145(process_1, process_2):
    """
    Args:
        process_1: an integer, number of times process 1 should be run
        process_2: an integer, number of times process 2 should be run

    Returns:
        obj: an integer, total time needed to minimize
    """
    # Create a new model
    m = Model("DrugProduction")

    # Decision variables
    time_p1 = m.addVar(name="Time_Process1")
    time_p2 = m.addVar(name="Time_Process2")

    # Objective: Minimize total time
    m.setObjective(time_p1 + time_p2, GRB.MINIMIZE)

    # Constraints
    # Process 1 constraints
    m.addConstr(35 * process_1 + 50 * process_2 >= 1200, "Min_Painkillers")
    m.addConstr(12 * process_1 + 30 * process_2 >= 1200, "Min_SleepingPills")
    m.addConstr(50 * process_1 <= 2000, "Material_Process1")

    # Process 2 constraints
    m.addConstr(50 * process_1 + 50 * process_2 <= 2000, "Material_Process2")

    # Solve the model
    m.optimize()

    # Check if a feasible solution was found
    if m.status == GRB.OPTIMAL:
        # Retrieve and return the total time needed
        obj = m.objVal
        print(f"Optimal time: {obj}")
        return obj
    else:
        print("No feasible solution found.")
        return None

# Example usage
optimal_time = prob_145(process_1=0, process_2=0)