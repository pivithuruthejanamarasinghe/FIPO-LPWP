# Import necessary libraries
from gurobipy import Model, GRB

def prob_145(process_1, process_2):
    """
    Solves the optimization problem to minimize the total time needed to produce pain killers and sleeping pills.
    
    Args:
        process_1: an integer, number of units of preliminary materials needed for process 1
        process_2: an integer, number of units of preliminary materials needed for process 2
    
    Returns:
        obj: an integer, total time needed to minimize
    """
    # Create a new model
    model = Model("drug_company")
    
    # Define variables
    x1 = model.addVar(name="x1")  # Number of hours process 1 is run
    x2 = model.addVar(name="x2")  # Number of hours process 2 is run
    
    # Set objective function (minimize total time)
    model.setObjective(x1 + x2, GRB.MINIMIZE)
    
    # Add constraints
    model.addConstr(35 * x1 + 50 * x2 >= 1200, "pain_killer_constraint")  # At least 1200 units of pain killers
    model.addConstr(12 * x1 + 30 * x2 >= 1200, "sleeping_pill_constraint")  # At least 1200 units of sleeping pills
    model.addConstr(50 * x1 + 60 * x2 <= 2000, "material_constraint")  # Available preliminary material constraint
    
    # Solve the model
    model.optimize()
    
    # Get the optimal solution
    obj = model.objVal
    
    return int(obj)

# Example usage
print(prob_145(50, 60))