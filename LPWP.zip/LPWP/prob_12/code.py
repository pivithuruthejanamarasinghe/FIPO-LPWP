
            import os
            import numpy as np
            import json 
            from gurobipy import Model, GRB, quicksum


            model = Model("OptimizationProblem")

            with open("data.json", "r") as f:
                data = json.load(f)

        


### Define the parameters

RegularSandwichEggs = data["RegularSandwichEggs"] # shape: [], definition: The number of eggs required for one regular sandwich

RegularSandwichBacon = data["RegularSandwichBacon"] # shape: [], definition: The number of slices of bacon required for one regular sandwich

SpecialSandwichEggs = data["SpecialSandwichEggs"] # shape: [], definition: The number of eggs required for one special sandwich

SpecialSandwichBacon = data["SpecialSandwichBacon"] # shape: [], definition: The number of slices of bacon required for one special sandwich

TotalEggs = data["TotalEggs"] # shape: [], definition: The total number of eggs available

TotalBacon = data["TotalBacon"] # shape: [], definition: The total number of slices of bacon available

ProfitRegularSandwich = data["ProfitRegularSandwich"] # shape: [], definition: The profit made from one regular sandwich

ProfitSpecialSandwich = data["ProfitSpecialSandwich"] # shape: [], definition: The profit made from one special sandwich



### Define the variables

SpecialSandwichCount = model.addVar(vtype=GRB.INTEGER, name="SpecialSandwichCount")



### Define the constraints

model.addConstr(2 * RegularSandwichCount + 3 * SpecialSandwichCount <= TotalEggs)
model.addConstr(RegularSandwichBacon * RegularSandwichCount + SpecialSandwichBacon * SpecialSandwichCount <= TotalBacon)
model.addConstr(RegularSandwichCount >= 0)
model.addConstr(SpecialSandwichCount >= 0)


### Define the objective

model.setObjective(ProfitRegularSandwich * RegularSandwichCount + ProfitSpecialSandwich * SpecialSandwichCount, GRB.MAXIMIZE)


### Optimize the model

model.optimize()



### Output optimal objective value

print("Optimal Objective Value: ", model.objVal)


            if model.status == GRB.OPTIMAL:
                with open("output_solution.txt", "w") as f:
                    f.write(str(model.objVal))
                print("Optimal Objective Value: ", model.objVal)
            else:
                with open("output_solution.txt", "w") as f:
                    f.write(model.status)
        