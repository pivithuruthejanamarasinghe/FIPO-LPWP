
def prob_12(regular, special):
    """
    Args:
        regular: an integer, the profit of a regular sandwich
        special: an integer, the profit of a special sandwich

    Returns:
        obj: an integer, the objective value (profit)
    """
    obj = 1e9
    # To be implemented
    return obj
