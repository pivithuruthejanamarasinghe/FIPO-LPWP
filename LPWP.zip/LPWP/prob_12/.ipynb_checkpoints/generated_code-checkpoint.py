from gurobipy import Model, GRB

def prob_12(regular, special):
    """
    Args:
        regular: an integer, the profit of a regular sandwich
        special: an integer, the profit of a special sandwich

    Returns:
        obj: an integer, the objective value (profit)
    """
    m = Model("sandwiches")
    
    # Variables
    x = m.addVar(name="regular", vtype=GRB.INTEGER)
    y = m.addVar(name="special", vtype=GRB.INTEGER)
    
    # Objective function
    m.setObjective(regular * x + special * y, GRB.MAXIMIZE)
    
    # Constraints
    m.addConstr(2 * x + 3 * y <= 40, "eggs")
    m.addConstr(3 * x + 5 * y <= 70, "bacon")
    
    # Non-negativity constraints
    m.addConstr(x >= 0, "non_neg_x")
    m.addConstr(y >= 0, "non_neg_y")
    
    # Solve model
    m.optimize()
    
    # Get solution
    obj = m.objVal
    
    return int(obj)