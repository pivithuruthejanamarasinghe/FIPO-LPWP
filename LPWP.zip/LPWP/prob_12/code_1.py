import os  
import numpy as np  
import json  
from gurobipy import Model, GRB, quicksum  

model = Model("OptimizationProblem")  

with open("data.json", "r") as f:  
    data = json.load(f)  

### Define the parameters  
RegularSandwichEggs = data["RegularSandwichEggs"]  
RegularSandwichBacon = data["RegularSandwichBacon"]  
SpecialSandwichEggs = data["SpecialSandwichEggs"]  
SpecialSandwichBacon = data["SpecialSandwichBacon"]  
TotalEggs = data["TotalEggs"]  
TotalBacon = data["TotalBacon"]  
ProfitRegularSandwich = data["ProfitRegularSandwich"]  
ProfitSpecialSandwich = data["ProfitSpecialSandwich"]  

### Define the variables  
RegularSandwichCount = model.addVar(vtype=GRB.INTEGER, name="RegularSandwichCount")  
SpecialSandwichCount = model.addVar(vtype=GRB.INTEGER, name="SpecialSandwichCount")  

### Define the constraints  
model.addConstr(RegularSandwichEggs * RegularSandwichCount + SpecialSandwichEggs * SpecialSandwichCount <= TotalEggs)  
model.addConstr(RegularSandwichBacon * RegularSandwichCount + SpecialSandwichBacon * SpecialSandwichCount <= TotalBacon)  
model.addConstr(RegularSandwichCount >= 0)  
model.addConstr(SpecialSandwichCount >= 0)  

### Define the objective  
model.setObjective(ProfitRegularSandwich * RegularSandwichCount + ProfitSpecialSandwich * SpecialSandwichCount, GRB.MAXIMIZE)  

### Optimize the model  
model.optimize()  

### Output optimal objective value  
if model.status == GRB.OPTIMAL:  
    print("Optimal Objective Value: ", model.objVal)  
    with open("output_solution.txt", "w") as f:  
        f.write(str(model.objVal))  
else:  
    print("No optimal solution found.")  
    with open("output_solution.txt", "w") as f:  
        f.write("Status: " + str(model.status))