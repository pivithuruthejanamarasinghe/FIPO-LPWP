# Importing the required library
from gurobipy import Model, GRB

def prob_138(medicine_A, medicine_B):
    """
    Args:
        medicine_A: number of people can be treated by one dose of medicine A (integer)
        medicine_B: number of people can be treated by one dose of medicine B (integer)
    Returns:
        obj: maximum number of people that can be treated (integer)
    """
    # Create a new model
    m = Model("diabetes_medicine")

    # Define variables
    x = m.addVar(name="medicine_A_doses")
    y = m.addVar(name="medicine_B_doses")

    # Set objective function
    m.setObjective(x * medicine_A + y * medicine_B, GRB.MAXIMIZE)

    # Add constraints
    m.addConstr(30 * x + 40 * y <= 300, "material_constraint")
    m.addConstr(50 * x + 30 * y <= 400, "mRNA_constraint")
    m.addConstr(x <= 5, "max_medicine_A_constraint")
    m.addConstr(y > x, "more_medicine_B_than_A_constraint")

    # Solve the model
    m.optimize()

    # Get the optimal solution
    obj = int(m.objVal)

    return obj