from pulp import LpProblem, LpMaximize, LpVariable, lpSum, LpStatus

def prob_138(medicine_A, medicine_B):
    """
    Args:
        medicine_A: number of doses for medicine A (integer)
        medicine_B: number of doses for medicine B (integer)
    Returns:
        max_people: maximum number of people that can be treated (integer)
    """
    # Define the problem
    prob = LpProblem("Maximize_Treated_People", LpMaximize)

    # Declare decision variables
    A = LpVariable('A', lowBound=0, cat='Integer')
    B = LpVariable('B', lowBound=0, cat='Integer')

    # Formulate the objective function
    prob += lpSum([12 * A + 8 * B])

    # Add constraints
    prob += 30 * A + 40 * B <= 300  # Material constraint
    prob += 50 * A + 30 * B <= 400  # mRNA constraint
    prob += B >= A + 1  # Medicine B must be larger than medicine A
    prob += A <= 5  # Maximum doses of medicine A

    # Solve the problem
    prob.solve()

    # Check if a solution exists
    if LpStatus[prob.status] == 'Optimal':
        max_people = lpSum([12 * A + 8 * B])
        return max_people
    else:
        raise ValueError("No optimal solution found.")

# Example usage
try:
    max_people_treated = prob_138(medicine_A=0, medicine_B=0)
    print(f"Maximum number of people that can be treated: {max_people_treated}")
except ValueError as e:
    print(e)