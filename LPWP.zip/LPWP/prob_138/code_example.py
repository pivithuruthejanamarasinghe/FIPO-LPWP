
def prob_138(medicine_A, medicine_B):
    """
    Args:
        medicine_A: number of people can be treated by one dose of medicine A (integer)
        medicine_B: number of people can be treated by one dose of medicine B (integer)
    Returns:
        obj: maximum number of people that can be treated (integer)
    """
    obj = 1e9
    # To be implemented
    return obj
