from pulp import *

def prob_1(color_printers, bw_printers):
    # Create the problem variable to contain the problem data
    prob = LpProblem("Maximize Profit", LpMaximize)

    # Create decision variables
    x = LpVariable('color_printers', lowBound=0, cat='Integer')
    y = LpVariable('bw_printers', lowBound=0, cat='Integer')

    # Add objective function
    prob += 200 * x + 70 * y

    # Add constraints
    prob += x <= 20
    prob += y <= 30
    prob += x + y <= 35

    # Solve the problem
    prob.solve()

    # Return the optimal objective value (profit)
    return value(prob.objective)

# Test the function
print(prob_1(0, 0))
print(prob_1(20, 0))
print(prob_1(0, 30))
print(prob_1(20, 30))