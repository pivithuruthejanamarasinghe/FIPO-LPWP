
            import os
            import numpy as np
            import json 
            from gurobipy import Model, GRB, quicksum


            model = Model("OptimizationProblem")

            with open("data.json", "r") as f:
                data = json.load(f)

        


### Define the parameters

TotalBudget = data["TotalBudget"] # shape: [], definition: The total budget available for investment, which is at most $760000.

CondosProfitPerDollar = data["CondosProfitPerDollar"] # shape: [], definition: The profit earned per dollar invested in condos, which is $0.50.

HousesProfitPerDollar = data["HousesProfitPerDollar"] # shape: [], definition: The profit earned per dollar invested in detached houses, which is $1.

MinCondosInvestmentPercentage = data["MinCondosInvestmentPercentage"] # shape: [], definition: The minimum percentage of the total investment that must be allocated to condos, which is 20%.

MinHousesInvestment = data["MinHousesInvestment"] # shape: [], definition: The minimum investment required in detached houses, which is $20000.



### Define the variables

H = model.addVar(vtype=GRB.CONTINUOUS, name="H")

C = model.addVar(vtype=GRB.CONTINUOUS, name="C")



### Define the constraints

model.addConstr(C + H <= 760000)
model.addConstr(C >= 0.25 * H)
model.addConstr(H >= 20000)
model.addConstr(C >= 0)
model.addConstr(H >= 0)


### Define the objective

model.setObjective(0.50 * C + H, GRB.MAXIMIZE)


### Optimize the model

model.optimize()



### Output optimal objective value

print("Optimal Objective Value: ", model.objVal)


            if model.status == GRB.OPTIMAL:
                with open("output_solution.txt", "w") as f:
                    f.write(str(model.objVal))
                print("Optimal Objective Value: ", model.objVal)
            else:
                with open("output_solution.txt", "w") as f:
                    f.write(model.status)
        